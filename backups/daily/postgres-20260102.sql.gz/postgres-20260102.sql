--
-- PostgreSQL database dump
--

\restrict oXVbUPcpKDjma1FM0IQS5uqa6Zo2bM3N1LwHefm1Cn3uP200bB9swnY2whjWuUX

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: BannerStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BannerStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SCHEDULED'
);


ALTER TYPE public."BannerStatus" OWNER TO postgres;

--
-- Name: BannerType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BannerType" AS ENUM (
    'ALL',
    'MAIN_PRODUCTS',
    'CATEGORY',
    'FOOTER',
    'CONTENT_HERO',
    'SPECIAL_PRICE'
);


ALTER TYPE public."BannerType" OWNER TO postgres;

--
-- Name: CartStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CartStatus" AS ENUM (
    'ACTIVE',
    'CHECKED_OUT'
);


ALTER TYPE public."CartStatus" OWNER TO postgres;

--
-- Name: CategoryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CategoryType" AS ENUM (
    'LIVESTOCK',
    'CONVENIENCE_FOOD',
    'FISHERIES',
    'SIDE_DISH'
);


ALTER TYPE public."CategoryType" OWNER TO postgres;

--
-- Name: CouponHistoryStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CouponHistoryStatus" AS ENUM (
    'ISSUED',
    'USED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."CouponHistoryStatus" OWNER TO postgres;

--
-- Name: CouponTargetGrade; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CouponTargetGrade" AS ENUM (
    'VIP',
    'VVIP'
);


ALTER TYPE public."CouponTargetGrade" OWNER TO postgres;

--
-- Name: CouponType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CouponType" AS ENUM (
    'PERCENT',
    'AMOUNT'
);


ALTER TYPE public."CouponType" OWNER TO postgres;

--
-- Name: OrderSituation; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderSituation" AS ENUM (
    'ORDER_NEW',
    'ORDER_PAYMENT_PENDING',
    'ORDER_PAYMENT_COMPLETED',
    'ORDER_IN_PREPARE',
    'ORDER_BEING_SHIPPED',
    'ORDER_SHIPPED',
    'ORDER_CANCELLED',
    'ORDER_RETURNED'
);


ALTER TYPE public."OrderSituation" OWNER TO postgres;

--
-- Name: RecipeCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RecipeCategory" AS ENUM (
    'RECIPE',
    'REVIEWS',
    'DAILY_LIFE'
);


ALTER TYPE public."RecipeCategory" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: banners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banners (
    id text NOT NULL,
    product_category_number text,
    product_id text,
    type public."BannerType" NOT NULL,
    status public."BannerStatus" DEFAULT 'ACTIVE'::public."BannerStatus" NOT NULL,
    title character varying(255),
    badge_text character varying(100),
    main_text text,
    cta_button_text character varying(100),
    cta_button_url character varying(500),
    image_url text NOT NULL,
    mobile_image_url text,
    display_order integer DEFAULT 0 NOT NULL,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.banners OWNER TO postgres;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    id text NOT NULL,
    cart_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    sale_price integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: carts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carts (
    id text NOT NULL,
    user_id text NOT NULL,
    status public."CartStatus" DEFAULT 'ACTIVE'::public."CartStatus" NOT NULL,
    total_amount integer DEFAULT 0 NOT NULL,
    checked_out_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.carts OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    product_category_number character varying(50) NOT NULL,
    name public."CategoryType" NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: coupon_histories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupon_histories (
    id text NOT NULL,
    coupon_id text NOT NULL,
    user_id text NOT NULL,
    order_id text,
    status public."CouponHistoryStatus" DEFAULT 'ISSUED'::public."CouponHistoryStatus" NOT NULL,
    issued_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    used_at timestamp(3) without time zone,
    expired_at timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone,
    discount_applied_amount integer,
    purchase_amount_at_use integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.coupon_histories OWNER TO postgres;

--
-- Name: coupons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupons (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    type public."CouponType" NOT NULL,
    discount_rate integer,
    discount_amount integer,
    min_purchase_amount integer DEFAULT 0 NOT NULL,
    max_discount_amount integer,
    image_url text,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_auto_issue boolean DEFAULT false NOT NULL,
    auto_issue_day_of_month timestamp(3) without time zone,
    target_grades public."CouponTargetGrade"[] DEFAULT ARRAY[]::public."CouponTargetGrade"[],
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.coupons OWNER TO postgres;

--
-- Name: memberships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memberships (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    min_price integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone
);


ALTER TABLE public.memberships OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    order_number text DEFAULT ''::text NOT NULL,
    item_wise_order_number text DEFAULT ''::text NOT NULL,
    total_order_amount integer NOT NULL,
    total_payment_amount integer NOT NULL,
    product_id text NOT NULL,
    product_name text DEFAULT ''::text NOT NULL,
    product_name_with_options text DEFAULT ''::text NOT NULL,
    quantity integer NOT NULL,
    recipient text DEFAULT ''::text NOT NULL,
    recipient_address_full text DEFAULT ''::text NOT NULL,
    recipient_postal_code integer NOT NULL,
    recipient_mobile_phone text DEFAULT ''::text NOT NULL,
    recipient_phone_number text DEFAULT ''::text NOT NULL,
    delivery_message text DEFAULT ''::text NOT NULL,
    sale_price integer NOT NULL,
    payment_type text DEFAULT ''::text NOT NULL,
    payment_method text DEFAULT ''::text NOT NULL,
    order_date text DEFAULT ''::text NOT NULL,
    orderer_name text DEFAULT ''::text NOT NULL,
    orderer_mobile_phone text DEFAULT ''::text NOT NULL,
    orderer_id text,
    desired_delivery_date text DEFAULT ''::text NOT NULL,
    membership_level_at_order_time text DEFAULT ''::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    situation public."OrderSituation",
    courier_company text,
    invoice_number text,
    cart_id text
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: points; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.points (
    id text NOT NULL,
    date character varying(50),
    user_id character varying(50),
    membership_level character varying(50),
    content character varying(50),
    order_number character varying(50),
    points_type character varying(50),
    available_points_increase integer,
    available_points_deduction integer,
    available_points_balance integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.points OWNER TO postgres;

--
-- Name: product_discounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_discounts (
    id text NOT NULL,
    status boolean DEFAULT false NOT NULL,
    product_id text NOT NULL,
    discount_rate integer NOT NULL,
    discount_start_date timestamp(3) without time zone,
    discount_end_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.product_discounts OWNER TO postgres;

--
-- Name: product_special_offers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_special_offers (
    id text NOT NULL,
    status boolean DEFAULT false NOT NULL,
    product_id text NOT NULL,
    discount_amount integer NOT NULL,
    special_price_applied integer,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone,
    updated_at timestamp(3) without time zone
);


ALTER TABLE public.product_special_offers OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    product_code text,
    own_product_code text,
    display_status text DEFAULT 'ACTIVE'::text,
    sale_status text,
    product_category_number text,
    product_category_new_product_area text,
    product_category_recommended_product_area text,
    product_name character varying(128),
    english_product_name text,
    product_name_for_management text,
    supplier_product_name text,
    model_name text,
    product_summary_description text,
    product_brief_description text,
    search_keyword_setting text,
    tax_classification text,
    consumer_price integer,
    supply_price integer,
    product_price integer,
    sale_price integer,
    use_sale_price_alternative_text text,
    sale_price_alternative_text text,
    order_quantity_limit_criteria text,
    min_order_quantity integer,
    max_order_quantity integer,
    reward_points integer,
    reward_points_classification text,
    common_event_info text,
    adult_verification text,
    option_usage text,
    item_composition_method text,
    option_display_method text,
    option_set_name text,
    option_input text,
    option_style text,
    button_image_setting text,
    color_setting text,
    required_or_not text,
    out_of_stock_display_text text,
    additional_input_option text,
    additional_input_option_name text,
    additional_input_option_required_or_not text,
    input_character_count text,
    image_registration_detail text,
    image_registration_list text,
    image_registration_small_list text,
    image_registration_thumbnail text,
    manufacturer text,
    supplier text,
    brand text,
    trend text,
    own_classification_code text,
    manufacturing_date text,
    release_date text,
    validity_period_usage text,
    validity_period text,
    origin integer,
    product_volume text,
    volume_weight text,
    product_payment_guide text,
    product_delivery_guide text,
    exchange_return_guide text,
    service_inquiry_guide text,
    delivery_info text,
    delivery_method text,
    domestic_overseas_delivery text,
    delivery_area text,
    delivery_fee_prepayment_setting text,
    delivery_period text,
    delivery_fee_classification text,
    delivery_fee_input text,
    product_classification_customs text,
    product_material text,
    english_product_material_customs text,
    fabric_customs text,
    seo_search_engine_exposure_setting text,
    seo_title text,
    seo_author text,
    seo_description text,
    seo_keywords text,
    seo_product_image_alt_text text,
    individual_payment_method_setting text,
    product_delivery_type_code text,
    store_pickup_setting text,
    product_total_weight integer,
    hs_code bigint,
    additional_item_01_today_departure_delivery_usage text,
    additional_item_02_today_departure_delivery_time text,
    additional_item_03_storage_method text,
    additional_item_04_origin text,
    additional_item_05_event text,
    additional_item_06_parcel_delivery text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    cta_button_url character varying(500)
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: recipes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipes (
    id text NOT NULL,
    title character varying(255) NOT NULL,
    "authorId" text,
    "authorName" character varying(100) NOT NULL,
    date_of_writing timestamp(3) without time zone NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    thumbnail_url text,
    content text NOT NULL,
    ingredients text[],
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    category public."RecipeCategory" NOT NULL
);


ALTER TABLE public.recipes OWNER TO postgres;

--
-- Name: refresh_token_used; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_token_used (
    id text NOT NULL,
    "refreshToken" text NOT NULL,
    "sessionId" text NOT NULL
);


ALTER TABLE public.refresh_token_used OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "refreshToken" text NOT NULL,
    ip text,
    "expiredAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: user_memberships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_memberships (
    id text NOT NULL,
    "userId" text NOT NULL,
    "membershipId" text NOT NULL,
    membership_name text NOT NULL,
    membership_description text NOT NULL,
    status text DEFAULT 'normal'::text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone,
    updated_by_admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_memberships OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    "userId" text NOT NULL,
    "roleId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    password text,
    name text NOT NULL,
    "membershipLevel" text,
    age integer,
    email text NOT NULL,
    phone_number text NOT NULL,
    total_used_points integer DEFAULT 0 NOT NULL,
    available_points integer DEFAULT 0 NOT NULL,
    registration_date text NOT NULL,
    dormancy_date text,
    withdrawal_date text,
    withdrawal_type text,
    reason_for_withdrawal text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(3) without time zone,
    total_purchase_amount integer DEFAULT 0 NOT NULL,
    dashboard_access boolean DEFAULT false NOT NULL,
    member_access boolean DEFAULT false NOT NULL,
    product_access boolean DEFAULT false NOT NULL,
    order_access boolean DEFAULT false NOT NULL,
    recipe_access boolean DEFAULT false NOT NULL,
    banner_access boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
bdc05d6e-02b1-49cd-a7f3-b8ac9cf3ae3a	b47033e772b8d795d97824b56627fd2e6f9d8d6b624ce12cdb98d07520a6e5c3	2025-12-30 11:02:54.936405+00	20251226054111_init	\N	\N	2025-12-30 11:02:54.888686+00	1
bb2cb1d2-0a8a-4728-a782-26648a0c47c4	47a21d9cb213edcd4259347e6d9f2f49d274f1192f64bfdf9b07781651b94036	2025-12-30 11:02:54.938741+00	20251226061650_adjust_type_3	\N	\N	2025-12-30 11:02:54.936883+00	1
76d866c3-ae46-4664-b5c8-1350ae67f9e4	b5745b00e89a834f4ac5100d4ef602e7bab63839fef5201748aa7bbf36003fcf	2025-12-30 11:02:54.944355+00	20251230062011_adjust_category	\N	\N	2025-12-30 11:02:54.939842+00	1
6907baa9-086d-4220-ad9b-5d4095819f10	862d0b46d0b1e634e9e22c06c4a2fe0bf21d71554c3c46176281554619b0dd85	2025-12-30 11:02:54.946461+00	20251230062215_adjust_banner	\N	\N	2025-12-30 11:02:54.944814+00	1
edd2a85b-667d-4d10-a973-2bdeb8f01b3f	48a4007df3a7f540d957a8544a1f579a81ebd34a161a45a10f34573ee9abb0c4	2025-12-30 11:03:10.041636+00	20251230110310_refactor_recipe	\N	\N	2025-12-30 11:03:10.028714+00	1
54a00ea1-dbab-4aa0-8c44-a407456a0469	d69a3b97545d3c7010d77efac89863c1ddadb4f069f4bd646aa23b850f938eaf	2025-12-31 09:25:47.57822+00	20251231092547_add_cart	\N	\N	2025-12-31 09:25:47.548394+00	1
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banners (id, product_category_number, product_id, type, status, title, badge_text, main_text, cta_button_text, cta_button_url, image_url, mobile_image_url, display_order, start_date, end_date, created_at, updated_at) FROM stdin;
13c38ad6-5548-4ce6-8557-3c0d2e747067	CAT001	9a37427d-a510-4cee-ab31-da230587a631	MAIN_PRODUCTS	ACTIVE	Premium Quality for Your Kitchen	Best Seller	Discover our finest selection of premium organic olive oil	Shop Now	/products/9a37427d-a510-4cee-ab31-da230587a631	https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=1200	https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800	1	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.547	2025-12-31 07:15:56.547
cb158af0-18eb-40c3-b092-c19ded7e3b7b	\N	\N	CATEGORY	ACTIVE	Shop Everything You Need	All Products	Browse our complete catalog of premium products	Shop All	/products	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800	2	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.549	2025-12-31 07:15:56.549
9da4b7d5-00ed-43e3-ae3f-960fe250ef5e	CAT001	\N	CATEGORY	ACTIVE	Explore Fresh Meats	New Arrivals	Browse our complete collection of fresh, premium meats	View Collection	/categories/meats	https://images.unsplash.com/photo-1535473895227-bdecb20fb157?w=1200	https://images.unsplash.com/photo-1535473895227-bdecb20fb157?w=800	3	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.55	2025-12-31 07:15:56.55
a5e7677c-9369-40a7-a3fb-edf4075ef870	CAT002	\N	CATEGORY	ACTIVE	Quick & Convenient Meals	Ready to Eat	Discover our range of delicious convenience foods for your busy lifestyle	Explore Convenience Foods	/categories/convenience-food	https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=1200	https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800	4	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.551	2025-12-31 07:15:56.551
34784b09-0788-479c-a0f9-e222e0136be4	CAT003	\N	CATEGORY	ACTIVE	Fresh Seafood Collection	Premium Quality	Discover our premium selection of fresh seafood	Explore Seafood	/categories/seafood	https://images.unsplash.com/photo-1512909006721-3d6018887383?w=1200	https://images.unsplash.com/photo-1512909006721-3d6018887383?w=800	5	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.553	2025-12-31 07:15:56.553
35bb1b27-e46c-4341-8da9-682f3c288839	CAT004	\N	CATEGORY	ACTIVE	Fresh From Farm to Table	Farm Fresh	Experience the difference of locally sourced, organic ingredients delivered daily	Learn More	/about/farm-fresh	https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=1200	https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=800	6	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.554	2025-12-31 07:15:56.554
8697f604-078b-417a-b9ae-06742c8cc06c	CAT002	\N	FOOTER	ACTIVE	Join Our Newsletter	\N	Get exclusive deals and recipes delivered to your inbox	Subscribe	/newsletter/subscribe	https://images.unsplash.com/photo-1505935428862-770b6f24f629?w=1200	https://images.unsplash.com/photo-1505935428862-770b6f24f629?w=800	8	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.555	2025-12-31 07:15:56.555
f67cf051-41e8-4595-97f8-cdb5eea93dd8	CAT003	\N	FOOTER	ACTIVE	Follow Us on Social Media	Connect	Stay updated with our latest products and special offers	Follow	/social	https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=1200	https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800	9	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.556	2025-12-31 07:15:56.556
c5f02bd6-e44e-4113-8fbc-db29e26380ab	CAT004	\N	FOOTER	ACTIVE	Customer Support	24/7	We are here to help you with any questions or concerns	Contact Us	/support	https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1200	https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800	10	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.557	2025-12-31 07:15:56.557
624557d5-7724-4ba2-b939-eeb4a19e86c4	CAT002	\N	CONTENT_HERO	ACTIVE	Valentine's Day Special	Coming Soon	Celebrate with our artisan bakery collection	Notify Me	/products/409173a0-ab8f-4237-986a-614a32624b35	https://images.unsplash.com/photo-1509440159596-0249088772ff?w=1200	https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800	11	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.563	2025-12-31 07:15:56.563
fec9886a-6eaf-4300-bc6c-f5a87763c2e5	CAT003	\N	SPECIAL_PRICE	ACTIVE	This Week's Special Offer	30% OFF	Wild Caught Salmon - Limited Time Only!	Get Discount	/products/5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=1200	https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=800	12	2025-01-01 00:00:00	2025-12-31 00:00:00	2025-12-31 07:15:56.564	2025-12-31 07:15:56.564
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (id, cart_id, product_id, quantity, sale_price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carts (id, user_id, status, total_amount, checked_out_at, created_at, updated_at) FROM stdin;
c381fa12-0be6-409a-b821-5270b9c35d92	user000	ACTIVE	0	\N	2026-01-02 06:21:07.233	2026-01-02 06:21:07.233
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (product_category_number, name, description, created_at, updated_at) FROM stdin;
CAT001	LIVESTOCK	Livestock products - Fresh premium meats and livestock products	2025-12-31 07:15:56.425	2025-12-31 07:15:56.425
CAT002	CONVENIENCE_FOOD	Convenience food - Quick and ready-to-eat meals for busy lifestyles	2025-12-31 07:15:56.427	2025-12-31 07:15:56.427
CAT003	FISHERIES	Fisheries - Fresh seafood and premium fish products	2025-12-31 07:15:56.428	2025-12-31 07:15:56.428
CAT004	SIDE_DISH	Side dish - Premium oils, condiments, and side dish ingredients	2025-12-31 07:15:56.429	2025-12-31 07:15:56.429
\.


--
-- Data for Name: coupon_histories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupon_histories (id, coupon_id, user_id, order_id, status, issued_at, used_at, expired_at, cancelled_at, discount_applied_amount, purchase_amount_at_use, created_at, updated_at) FROM stdin;
47ab40ac-b5ad-4f72-8ae4-19a7f4a37da5	602878d8-5bfb-4dc0-9c18-8c28069e295e	user015	e1799dda-0984-464c-b371-27021961e44e	USED	2025-11-29 09:37:39.597	2025-12-09 05:12:16.921	\N	\N	8722	500542	2025-12-31 07:15:56.529	2025-12-31 07:15:56.529
1c28658d-ffa7-406c-aef6-1abacb34dbae	624f25e3-de02-4f8c-b604-b12d53e77920	user014	87f93695-39ca-4948-826e-379148b84a50	USED	2025-10-17 16:48:28.983	2025-10-28 19:51:24.135	\N	\N	7410	239527	2025-12-31 07:15:56.532	2025-12-31 07:15:56.532
97481975-e224-4642-b09e-242a74904c0a	d5976a74-3d36-4aac-b611-fdeadd43ae4b	user016	95359725-035a-4c8d-8522-01389f90b1ed	ISSUED	2025-12-19 00:53:12.34	\N	\N	\N	\N	\N	2025-12-31 07:15:56.533	2025-12-31 07:15:56.533
e3344fd6-505a-42f2-92cd-0b32824d48da	a8921ad9-11af-4bd9-a80d-69ffbf4e1388	user013	\N	ISSUED	2025-10-11 01:09:31.132	\N	\N	\N	\N	\N	2025-12-31 07:15:56.534	2025-12-31 07:15:56.534
e7327606-f946-4c42-bdb1-91c39822fa74	d5976a74-3d36-4aac-b611-fdeadd43ae4b	user020	8fdfbcb5-f041-48de-98d4-9570f1eadda0	ISSUED	2025-12-04 23:23:01.831	\N	\N	\N	\N	\N	2025-12-31 07:15:56.535	2025-12-31 07:15:56.535
c3407c74-e379-4290-8e3a-fb6a0ae4d34c	a8921ad9-11af-4bd9-a80d-69ffbf4e1388	user019	65023197-1f26-4d5b-a942-b64108fbd967	USED	2025-10-19 05:35:25.459	2025-11-01 14:36:56.603	\N	\N	6921	273172	2025-12-31 07:15:56.536	2025-12-31 07:15:56.536
ec634a38-f14b-4fe2-bc24-76132b43046b	624f25e3-de02-4f8c-b604-b12d53e77920	user014	e1799dda-0984-464c-b371-27021961e44e	USED	2025-12-10 23:00:37.606	2025-12-21 03:41:15.432	\N	\N	38413	519223	2025-12-31 07:15:56.537	2025-12-31 07:15:56.537
b3842060-82ec-4160-8ebc-b8b7106a7c85	d5976a74-3d36-4aac-b611-fdeadd43ae4b	user019	2721a200-a71a-4cc9-bbba-318a48476ff6	USED	2025-10-13 02:55:52.615	2025-11-06 06:43:10.977	\N	\N	46771	212704	2025-12-31 07:15:56.538	2025-12-31 07:15:56.538
950b8e1d-8790-4515-ad13-41031fe57e9e	624f25e3-de02-4f8c-b604-b12d53e77920	user020	23db39e5-5f34-4f09-92aa-31ec6f00cbd6	USED	2025-12-29 04:33:39.978	2026-01-26 15:26:00.988	\N	\N	6517	597749	2025-12-31 07:15:56.538	2025-12-31 07:15:56.538
1769148c-aba4-4a07-bc01-0b8e00b691e0	602878d8-5bfb-4dc0-9c18-8c28069e295e	user015	4abe0e92-22e5-40e7-ab07-58b6769eb348	ISSUED	2025-11-25 04:53:59.111	\N	\N	\N	\N	\N	2025-12-31 07:15:56.539	2025-12-31 07:15:56.539
7382db66-7723-49b8-8233-276a1d426238	a8921ad9-11af-4bd9-a80d-69ffbf4e1388	user018	e1799dda-0984-464c-b371-27021961e44e	USED	2025-12-20 04:08:00.166	2025-12-20 12:10:16.754	\N	\N	33738	183060	2025-12-31 07:15:56.54	2025-12-31 07:15:56.54
3c584380-743f-41f9-83fc-c637bcda873c	602878d8-5bfb-4dc0-9c18-8c28069e295e	user014	\N	ISSUED	2025-11-27 07:19:47.522	\N	\N	\N	\N	\N	2025-12-31 07:15:56.541	2025-12-31 07:15:56.541
ad933392-5f3b-4ce2-bc0a-2f66a530baec	602878d8-5bfb-4dc0-9c18-8c28069e295e	user018	87f93695-39ca-4948-826e-379148b84a50	ISSUED	2025-10-02 21:08:50.789	\N	\N	\N	\N	\N	2025-12-31 07:15:56.542	2025-12-31 07:15:56.542
93748b4e-1e0a-4243-93c1-bfe58b0ae717	624f25e3-de02-4f8c-b604-b12d53e77920	user021	\N	ISSUED	2025-11-02 13:45:54.663	\N	\N	\N	\N	\N	2025-12-31 07:15:56.542	2025-12-31 07:15:56.542
066a9e9f-5bbe-4a9f-b180-227bf7a73908	624f25e3-de02-4f8c-b604-b12d53e77920	user016	bf8117e6-46f6-43ce-b6d6-3fb7816e9918	USED	2025-12-15 08:52:14.061	2025-12-18 05:25:26.105	\N	\N	39084	240851	2025-12-31 07:15:56.543	2025-12-31 07:15:56.543
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupons (id, name, code, type, discount_rate, discount_amount, min_purchase_amount, max_discount_amount, image_url, start_date, end_date, is_active, is_auto_issue, auto_issue_day_of_month, target_grades, created_at, updated_at) FROM stdin;
d5976a74-3d36-4aac-b611-fdeadd43ae4b	VIP Welcome Coupon	VIP-WELCOME-2025	PERCENT	20	\N	100000	50000	\N	2025-01-01 00:00:00	2025-12-31 00:00:00	t	t	2025-01-01 00:00:00	{VIP}	2025-12-31 07:15:56.524	2025-12-31 07:15:56.524
a8921ad9-11af-4bd9-a80d-69ffbf4e1388	VVIP Exclusive Discount	VVIP-EXCLUSIVE-2025	AMOUNT	\N	100000	500000	\N	\N	2025-01-01 00:00:00	2025-12-31 00:00:00	t	t	2025-01-01 00:00:00	{VVIP}	2025-12-31 07:15:56.526	2025-12-31 07:15:56.526
624f25e3-de02-4f8c-b604-b12d53e77920	Premium Member Monthly Bonus	PREMIUM-MONTHLY-2025	PERCENT	15	\N	200000	30000	\N	2025-01-01 00:00:00	2025-12-31 00:00:00	t	t	2025-01-15 00:00:00	{VIP,VVIP}	2025-12-31 07:15:56.527	2025-12-31 07:15:56.527
602878d8-5bfb-4dc0-9c18-8c28069e295e	New Year Special	NEWYEAR-2025	AMOUNT	\N	50000	300000	\N	\N	2025-01-01 00:00:00	2025-01-31 00:00:00	t	f	2025-01-01 00:00:00	{}	2025-12-31 07:15:56.528	2025-12-31 07:15:56.528
\.


--
-- Data for Name: memberships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.memberships (id, name, description, min_price, created_at, updated_at) FROM stdin;
e7276b95-d0f2-4374-967c-8defcdbf99bb	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	1000000	2025-12-31 07:15:55.184	2025-12-31 07:15:55.184
e11341eb-7c17-416b-9fd9-332bbaf2f338	VIP	Very Important Person - Premium membership with special privileges	500000	2025-12-31 07:15:55.194	2025-12-31 07:15:55.194
79cdbf05-ce52-47b8-a2a4-0917649d3086	GOLD	Gold membership - Enhanced benefits and rewards	300000	2025-12-31 07:15:55.196	2025-12-31 07:15:55.196
1a686aac-df12-49bd-a73b-d82dacbe1c2c	SILVER	Silver membership - Standard benefits package	150000	2025-12-31 07:15:55.198	2025-12-31 07:15:55.198
c4f841c5-3acc-4ee6-aaa4-3ca139b17e0c	GENERAL	General membership - Entry level membership for users with less than 150000	0	2025-12-31 07:15:55.199	2025-12-31 07:15:55.199
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, order_number, item_wise_order_number, total_order_amount, total_payment_amount, product_id, product_name, product_name_with_options, quantity, recipient, recipient_address_full, recipient_postal_code, recipient_mobile_phone, recipient_phone_number, delivery_message, sale_price, payment_type, payment_method, order_date, orderer_name, orderer_mobile_phone, orderer_id, desired_delivery_date, membership_level_at_order_time, created_at, updated_at, situation, courier_company, invoice_number, cart_id) FROM stdin;
a1a6f569-712f-4db0-b571-8e618b220487	ORD000001	ITEM000001-01	28000	28000	9a37427d-a510-4cee-ab31-da230587a631	Premium Organic Olive Oil	Premium Organic Olive Oil	1	USER4	Seoul, Gangnam-gu, Teheran-ro 100	14487	010-1015-5015	010-1015-5015	Please leave at the door	28000	ONLINE	BANK_TRANSFER	2025-09-25	USER4	010-1015-5015	user015	2026-01-04	VVIP	2025-12-31 07:15:56.442	2025-12-31 07:15:56.442	ORDER_NEW	GS Postbox 택배	\N	\N
16bf931f-bd56-40d6-8920-72e769b636b6	ORD000002	ITEM000002-01	160000	160000	5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	4	USER2	Seoul, Gangnam-gu, Teheran-ro 101	39075	010-1013-5013	010-1013-5013		40000	ONLINE	BANK_TRANSFER	2025-12-25	USER2	010-1013-5013	user013	2026-01-04	VVIP	2025-12-31 07:15:56.445	2025-12-31 07:15:56.445	ORDER_CANCELLED	대신택배	\N	\N
ef1352b1-1b14-4136-9f9e-e0d5edf0b074	ORD000003	ITEM000003-01	240000	240000	79124b2b-1ac7-4f14-b87d-098a80d7fe53	Organic Vegetable Box (Large)	Organic Vegetable Box (Large)	5	USER9	Seoul, Gangnam-gu, Teheran-ro 102	28069	010-1020-5020	010-1020-5020		48000	ONLINE	KAKAO_PAY	2025-12-04	USER9	010-1020-5020	user020	2026-01-05	GOLD	2025-12-31 07:15:56.446	2025-12-31 07:15:56.446	ORDER_SHIPPED	한진택배	\N	\N
dc8049b5-7b6c-43f7-a246-72118ae92751	ORD000004	ITEM000004-01	210000	210000	053326cf-f86e-4b8d-ac90-4af9e3766da0	Premium Wagyu Beef Set	Premium Wagyu Beef Set	2	USER1	Seoul, Gangnam-gu, Teheran-ro 103	25150	010-1012-5012	010-1012-5012	Please leave at the door	105000	ONLINE	BANK_TRANSFER	2025-08-20	USER1	010-1012-5012	user012	2026-01-11	GENERAL	2025-12-31 07:15:56.448	2025-12-31 07:15:56.448	ORDER_SHIPPED	CJ대한통운	\N	\N
bf8117e6-46f6-43ce-b6d6-3fb7816e9918	ORD000005	ITEM000005-01	26000	26000	409173a0-ab8f-4237-986a-614a32624b35	Artisan Whole Grain Bread	Artisan Whole Grain Bread	4	USER5	Seoul, Gangnam-gu, Teheran-ro 104	52290	010-1016-5016	010-1016-5016		6500	ONLINE	CARD	2025-10-09	USER5	010-1016-5016	user016	2025-12-31	VVIP	2025-12-31 07:15:56.45	2025-12-31 07:15:56.45	ORDER_RETURNED	대신택배	\N	\N
110fdac8-34e3-4c33-8d97-2bde1dea14f1	ORD000006	ITEM000006-01	80000	80000	5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	2	USER10	Seoul, Gangnam-gu, Teheran-ro 105	51877	010-1021-5021	010-1021-5021		40000	ONLINE	KAKAO_PAY	2025-09-07	USER10	010-1021-5021	user021	2026-01-01	GOLD	2025-12-31 07:15:56.452	2025-12-31 07:15:56.452	ORDER_RETURNED	우체국택배	\N	\N
3020f2c6-a2ba-4fa5-8bed-8be230351d7b	ORD000007	ITEM000007-01	6500	6500	409173a0-ab8f-4237-986a-614a32624b35	Artisan Whole Grain Bread	Artisan Whole Grain Bread	1	USER8	Seoul, Gangnam-gu, Teheran-ro 106	59661	010-1019-5019	010-1019-5019	Please leave at the door	6500	ONLINE	BANK_TRANSFER	2025-10-17	USER8	010-1019-5019	user019	2026-01-11	VIP	2025-12-31 07:15:56.454	2025-12-31 07:15:56.454	ORDER_RETURNED	한진택배	\N	\N
42dd5f88-2d62-447d-9d88-3853ced9d85f	ORD000008	ITEM000008-01	28000	28000	9a37427d-a510-4cee-ab31-da230587a631	Premium Organic Olive Oil	Premium Organic Olive Oil	1	USER10	Seoul, Gangnam-gu, Teheran-ro 107	43684	010-1021-5021	010-1021-5021		28000	ONLINE	KAKAO_PAY	2025-07-29	USER10	010-1021-5021	user021	2026-01-10	GOLD	2025-12-31 07:15:56.456	2025-12-31 07:15:56.456	ORDER_PAYMENT_COMPLETED	CU편의점택배	\N	\N
d1a18d03-16fc-4f8c-9279-3df5e7d31543	ORD000009	ITEM000009-01	80000	80000	5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	2	USER10	Seoul, Gangnam-gu, Teheran-ro 108	17796	010-1021-5021	010-1021-5021		40000	ONLINE	KAKAO_PAY	2025-09-30	USER10	010-1021-5021	user021	2026-01-05	GOLD	2025-12-31 07:15:56.457	2025-12-31 07:15:56.457	ORDER_PAYMENT_PENDING	CU편의점택배	\N	\N
7c449b36-533c-4501-979a-1b749085c6f8	ORD000010	ITEM000010-01	200000	200000	5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	5	USER2	Seoul, Gangnam-gu, Teheran-ro 109	39156	010-1013-5013	010-1013-5013	Please leave at the door	40000	ONLINE	CARD	2025-07-12	USER2	010-1013-5013	user013	2026-01-05	VVIP	2025-12-31 07:15:56.461	2025-12-31 07:15:56.461	ORDER_PAYMENT_COMPLETED	한진택배	\N	\N
2721a200-a71a-4cc9-bbba-318a48476ff6	ORD000011	ITEM000011-01	19500	19500	409173a0-ab8f-4237-986a-614a32624b35	Artisan Whole Grain Bread	Artisan Whole Grain Bread	3	USER10	Seoul, Gangnam-gu, Teheran-ro 110	84409	010-1021-5021	010-1021-5021		6500	ONLINE	KAKAO_PAY	2025-08-16	USER10	010-1021-5021	user021	2026-01-09	GOLD	2025-12-31 07:15:56.463	2025-12-31 07:15:56.463	ORDER_PAYMENT_COMPLETED	CU편의점택배	\N	\N
6de95c08-2d02-4b6e-b0c7-6d2eda9755f1	ORD000012	ITEM000012-01	315000	315000	053326cf-f86e-4b8d-ac90-4af9e3766da0	Premium Wagyu Beef Set	Premium Wagyu Beef Set	3	USER4	Seoul, Gangnam-gu, Teheran-ro 111	89855	010-1015-5015	010-1015-5015		105000	ONLINE	BANK_TRANSFER	2025-12-20	USER4	010-1015-5015	user015	2026-01-12	VVIP	2025-12-31 07:15:56.465	2025-12-31 07:15:56.465	ORDER_NEW	로젠택배	\N	\N
8fdfbcb5-f041-48de-98d4-9570f1eadda0	ORD000013	ITEM000013-01	105000	105000	053326cf-f86e-4b8d-ac90-4af9e3766da0	Premium Wagyu Beef Set	Premium Wagyu Beef Set	1	USER4	Seoul, Gangnam-gu, Teheran-ro 112	66425	010-1015-5015	010-1015-5015	Please leave at the door	105000	ONLINE	CARD	2025-12-25	USER4	010-1015-5015	user015	2026-01-01	VVIP	2025-12-31 07:15:56.467	2025-12-31 07:15:56.467	ORDER_BEING_SHIPPED	대신택배	\N	\N
4989f593-482c-4ae7-8e61-2cc9f7e9be15	ORD000014	ITEM000014-01	140000	140000	9a37427d-a510-4cee-ab31-da230587a631	Premium Organic Olive Oil	Premium Organic Olive Oil	5	USER2	Seoul, Gangnam-gu, Teheran-ro 113	70439	010-1013-5013	010-1013-5013		28000	ONLINE	CARD	2025-07-25	USER2	010-1013-5013	user013	2026-01-03	VVIP	2025-12-31 07:15:56.468	2025-12-31 07:15:56.468	ORDER_CANCELLED	대신택배	\N	\N
e301af7a-9720-4c7d-a320-af04712c5482	ORD000015	ITEM000015-01	210000	210000	053326cf-f86e-4b8d-ac90-4af9e3766da0	Premium Wagyu Beef Set	Premium Wagyu Beef Set	2	USER2	Seoul, Gangnam-gu, Teheran-ro 114	47025	010-1013-5013	010-1013-5013		105000	ONLINE	CARD	2025-12-01	USER2	010-1013-5013	user013	2026-01-06	VVIP	2025-12-31 07:15:56.47	2025-12-31 07:15:56.47	ORDER_IN_PREPARE	로젠택배	\N	\N
4abe0e92-22e5-40e7-ab07-58b6769eb348	ORD000016	ITEM000016-01	6500	6500	409173a0-ab8f-4237-986a-614a32624b35	Artisan Whole Grain Bread	Artisan Whole Grain Bread	1	USER8	Seoul, Gangnam-gu, Teheran-ro 115	15438	010-1019-5019	010-1019-5019	Please leave at the door	6500	ONLINE	CARD	2025-12-24	USER8	010-1019-5019	user019	2026-01-09	VIP	2025-12-31 07:15:56.471	2025-12-31 07:15:56.471	ORDER_PAYMENT_PENDING	한진택배	\N	\N
d1651343-a91d-4574-afe7-fdc9ad989729	ORD000017	ITEM000017-01	112000	112000	9a37427d-a510-4cee-ab31-da230587a631	Premium Organic Olive Oil	Premium Organic Olive Oil	4	USER6	Seoul, Gangnam-gu, Teheran-ro 116	30398	010-1017-5017	010-1017-5017		28000	ONLINE	KAKAO_PAY	2025-08-27	USER6	010-1017-5017	user017	2026-01-05	GOLD	2025-12-31 07:15:56.473	2025-12-31 07:15:56.473	ORDER_IN_PREPARE	CJ대한통운	\N	\N
515a53b7-ab39-4768-8b2e-af827e36759d	ORD000018	ITEM000018-01	112000	112000	9a37427d-a510-4cee-ab31-da230587a631	Premium Organic Olive Oil	Premium Organic Olive Oil	4	USER3	Seoul, Gangnam-gu, Teheran-ro 117	61223	010-1014-5014	010-1014-5014		28000	ONLINE	KAKAO_PAY	2025-09-10	USER3	010-1014-5014	user014	2026-01-11	VIP	2025-12-31 07:15:56.475	2025-12-31 07:15:56.475	ORDER_CANCELLED	GS Postbox 택배	\N	\N
95359725-035a-4c8d-8522-01389f90b1ed	ORD000019	ITEM000019-01	26000	26000	409173a0-ab8f-4237-986a-614a32624b35	Artisan Whole Grain Bread	Artisan Whole Grain Bread	4	USER5	Seoul, Gangnam-gu, Teheran-ro 118	80723	010-1016-5016	010-1016-5016	Please leave at the door	6500	ONLINE	BANK_TRANSFER	2025-10-13	USER5	010-1016-5016	user016	2026-01-12	VVIP	2025-12-31 07:15:56.477	2025-12-31 07:15:56.477	ORDER_NEW	롯데택배	\N	\N
87f93695-39ca-4948-826e-379148b84a50	ORD000020	ITEM000020-01	160000	160000	5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	4	USER4	Seoul, Gangnam-gu, Teheran-ro 119	39000	010-1015-5015	010-1015-5015		40000	ONLINE	CARD	2025-11-16	USER4	010-1015-5015	user015	2026-01-05	VVIP	2025-12-31 07:15:56.478	2025-12-31 07:15:56.478	ORDER_CANCELLED	대신택배	\N	\N
23db39e5-5f34-4f09-92aa-31ec6f00cbd6	ORD000021	ITEM000021-01	40000	40000	5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	1	USER10	Seoul, Gangnam-gu, Teheran-ro 120	93633	010-1021-5021	010-1021-5021		40000	ONLINE	BANK_TRANSFER	2025-10-25	USER10	010-1021-5021	user021	2026-01-09	GOLD	2025-12-31 07:15:56.48	2025-12-31 07:15:56.48	ORDER_IN_PREPARE	롯데택배	\N	\N
72a8d873-3c9c-469c-b8da-f7c111be1522	ORD000022	ITEM000022-01	420000	420000	053326cf-f86e-4b8d-ac90-4af9e3766da0	Premium Wagyu Beef Set	Premium Wagyu Beef Set	4	USER7	Seoul, Gangnam-gu, Teheran-ro 121	33079	010-1018-5018	010-1018-5018	Please leave at the door	105000	ONLINE	BANK_TRANSFER	2025-12-21	USER7	010-1018-5018	user018	2025-12-31	VVIP	2025-12-31 07:15:56.481	2025-12-31 07:15:56.481	ORDER_IN_PREPARE	로젠택배	\N	\N
65023197-1f26-4d5b-a942-b64108fbd967	ORD000023	ITEM000023-01	160000	160000	5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	4	USER2	Seoul, Gangnam-gu, Teheran-ro 122	52433	010-1013-5013	010-1013-5013		40000	ONLINE	BANK_TRANSFER	2025-07-31	USER2	010-1013-5013	user013	2026-01-07	VVIP	2025-12-31 07:15:56.483	2025-12-31 07:15:56.483	ORDER_SHIPPED	GS Postbox 택배	\N	\N
e1799dda-0984-464c-b371-27021961e44e	ORD000024	ITEM000024-01	105000	105000	053326cf-f86e-4b8d-ac90-4af9e3766da0	Premium Wagyu Beef Set	Premium Wagyu Beef Set	1	USER6	Seoul, Gangnam-gu, Teheran-ro 123	28895	010-1017-5017	010-1017-5017		105000	ONLINE	BANK_TRANSFER	2025-12-17	USER6	010-1017-5017	user017	2026-01-09	GOLD	2025-12-31 07:15:56.485	2025-12-31 07:15:56.485	ORDER_CANCELLED	CU편의점택배	\N	\N
cb2557e3-83c6-4e2c-a4be-6089de87d17c	ORD000025	ITEM000025-01	105000	105000	053326cf-f86e-4b8d-ac90-4af9e3766da0	Premium Wagyu Beef Set	Premium Wagyu Beef Set	1	USER4	Seoul, Gangnam-gu, Teheran-ro 124	19013	010-1015-5015	010-1015-5015	Please leave at the door	105000	ONLINE	CARD	2025-08-14	USER4	010-1015-5015	user015	2026-01-01	VVIP	2025-12-31 07:15:56.486	2025-12-31 07:15:56.486	ORDER_SHIPPED	한진택배	\N	\N
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.points (id, date, user_id, membership_level, content, order_number, points_type, available_points_increase, available_points_deduction, available_points_balance, created_at, updated_at) FROM stdin;
b771b5a7-2539-4621-a3b4-a105df19e491	2025-08-17	user000	SILVER	Order reward points	ORD000021	EARNED	1046	0	9103	2025-12-31 07:15:56.488	2025-12-31 07:15:56.488
460f7575-a5e0-4952-86f0-d8c20ee50957	2025-07-26	user001	GENERAL	Order reward points	ORD000005	EARNED	533	0	10384	2025-12-31 07:15:56.49	2025-12-31 07:15:56.49
373a1be2-4aaa-4250-8465-3f38ee99cdb4	2025-09-21	user002	GOLD	Order reward points	ORD000025	EARNED	503	0	8258	2025-12-31 07:15:56.491	2025-12-31 07:15:56.491
ad8f7b4f-c0c2-48d9-ba3e-f15b2623967b	2025-08-20	user003	GENERAL	Order reward points	ORD000006	EARNED	2265	0	5182	2025-12-31 07:15:56.492	2025-12-31 07:15:56.492
2250f179-a9a1-42cf-8737-0aa0645d0010	2025-12-28	user004	SILVER	Order reward points	ORD000001	EARNED	4167	0	20595	2025-12-31 07:15:56.493	2025-12-31 07:15:56.493
79ffe5b1-5b5a-4fee-9e6d-06b2287c4eba	2025-12-06	user005	SILVER	Points redemption	ORD000024	USED	0	2872	-1576	2025-12-31 07:15:56.495	2025-12-31 07:15:56.495
e220c0ab-b994-45a3-bd70-017202a6e814	2025-07-24	user006	GOLD	Order reward points	ORD000019	EARNED	2345	0	14442	2025-12-31 07:15:56.496	2025-12-31 07:15:56.496
c4318662-ccd1-4687-a39e-620636420316	2025-12-19	user007	GOLD	Points redemption	ORD000023	USED	0	510	1318	2025-12-31 07:15:56.497	2025-12-31 07:15:56.497
b7085ea2-26ee-4e5c-b85b-aa733f3cf60f	2025-07-15	user008	GENERAL	Order reward points	ORD000016	EARNED	4647	0	19689	2025-12-31 07:15:56.498	2025-12-31 07:15:56.498
6375adbd-682d-4656-8252-c2138dae25ce	2025-07-22	user009	GENERAL	Order reward points	ORD000023	EARNED	3299	0	5680	2025-12-31 07:15:56.498	2025-12-31 07:15:56.498
6ba60029-093f-4722-8cd6-64fa648f89e6	2025-09-09	user010	GENERAL	Order reward points	ORD000016	EARNED	1311	0	7251	2025-12-31 07:15:56.499	2025-12-31 07:15:56.499
bb8994e2-0b94-460b-a37d-7e07b0f5ac34	2025-07-18	user011	SILVER	Order reward points	ORD000019	EARNED	4200	0	11578	2025-12-31 07:15:56.5	2025-12-31 07:15:56.5
a68c7d0a-8070-4663-86a1-8f4f54a80fb4	2025-07-17	user012	GENERAL	Order reward points	ORD000024	EARNED	3810	0	15631	2025-12-31 07:15:56.501	2025-12-31 07:15:56.501
c80bc502-b37f-4516-94cf-7ca3ba5cbe19	2025-09-18	user013	VVIP	Order reward points	ORD000009	EARNED	2610	0	19935	2025-12-31 07:15:56.502	2025-12-31 07:15:56.502
0ca67227-da07-48be-95a3-51cd49df91ce	2025-12-17	user014	VIP	Order reward points	ORD000016	EARNED	2910	0	21140	2025-12-31 07:15:56.503	2025-12-31 07:15:56.503
fbb27cf3-e729-46b3-9cbb-351229218ea7	2025-09-29	user015	VVIP	Points redemption	ORD000006	USED	0	1651	6087	2025-12-31 07:15:56.505	2025-12-31 07:15:56.505
07cfd098-983e-44a3-9705-2e272639eb9d	2025-10-01	user016	VVIP	Order reward points	ORD000002	EARNED	3179	0	12787	2025-12-31 07:15:56.506	2025-12-31 07:15:56.506
913833a3-15c5-48f9-b8ec-0f5665399bf7	2025-08-19	user017	GOLD	Order reward points	ORD000007	EARNED	1224	0	20713	2025-12-31 07:15:56.507	2025-12-31 07:15:56.507
246b158f-e916-4a05-871d-c102fb67cc07	2025-09-14	user018	VVIP	Points redemption	ORD000011	USED	0	1961	-983	2025-12-31 07:15:56.508	2025-12-31 07:15:56.508
00a99e06-e4b1-4e6c-a226-64a7bd37473e	2025-12-04	user019	VIP	Order reward points	ORD000007	EARNED	720	0	8301	2025-12-31 07:15:56.509	2025-12-31 07:15:56.509
75b21657-ba2f-4a59-9e6a-ecb41847399a	2025-08-19	user020	GOLD	Order reward points	ORD000012	EARNED	2746	0	8432	2025-12-31 07:15:56.51	2025-12-31 07:15:56.51
76fa98ed-c5de-4810-b093-f8d3ef74d905	2025-08-12	user021	GOLD	Order reward points	ORD000004	EARNED	952	0	16591	2025-12-31 07:15:56.511	2025-12-31 07:15:56.511
\.


--
-- Data for Name: product_discounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_discounts (id, status, product_id, discount_rate, discount_start_date, discount_end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_special_offers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_special_offers (id, status, product_id, discount_amount, special_price_applied, start_date, end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, product_code, own_product_code, display_status, sale_status, product_category_number, product_category_new_product_area, product_category_recommended_product_area, product_name, english_product_name, product_name_for_management, supplier_product_name, model_name, product_summary_description, product_brief_description, search_keyword_setting, tax_classification, consumer_price, supply_price, product_price, sale_price, use_sale_price_alternative_text, sale_price_alternative_text, order_quantity_limit_criteria, min_order_quantity, max_order_quantity, reward_points, reward_points_classification, common_event_info, adult_verification, option_usage, item_composition_method, option_display_method, option_set_name, option_input, option_style, button_image_setting, color_setting, required_or_not, out_of_stock_display_text, additional_input_option, additional_input_option_name, additional_input_option_required_or_not, input_character_count, image_registration_detail, image_registration_list, image_registration_small_list, image_registration_thumbnail, manufacturer, supplier, brand, trend, own_classification_code, manufacturing_date, release_date, validity_period_usage, validity_period, origin, product_volume, volume_weight, product_payment_guide, product_delivery_guide, exchange_return_guide, service_inquiry_guide, delivery_info, delivery_method, domestic_overseas_delivery, delivery_area, delivery_fee_prepayment_setting, delivery_period, delivery_fee_classification, delivery_fee_input, product_classification_customs, product_material, english_product_material_customs, fabric_customs, seo_search_engine_exposure_setting, seo_title, seo_author, seo_description, seo_keywords, seo_product_image_alt_text, individual_payment_method_setting, product_delivery_type_code, store_pickup_setting, product_total_weight, hs_code, additional_item_01_today_departure_delivery_usage, additional_item_02_today_departure_delivery_time, additional_item_03_storage_method, additional_item_04_origin, additional_item_05_event, additional_item_06_parcel_delivery, created_at, updated_at, cta_button_url) FROM stdin;
9a37427d-a510-4cee-ab31-da230587a631	PROD001	OWN001	ACTIVE	AVAILABLE	CAT001	\N	\N	Premium Organic Olive Oil	Premium Organic Olive Oil	\N	\N	\N	\N	\N	\N	TAXABLE	35000	25000	30000	28000	\N	\N	\N	1	100	280	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Organic Foods Co.	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	PARCEL	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-31 07:15:56.431	2025-12-31 07:15:56.431	\N
409173a0-ab8f-4237-986a-614a32624b35	PROD002	OWN002	ACTIVE	AVAILABLE	CAT002	\N	\N	Artisan Whole Grain Bread	Artisan Whole Grain Bread	\N	\N	\N	\N	\N	\N	TAXABLE	8000	5000	7000	6500	\N	\N	\N	1	50	65	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Artisan Bakery	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	\N	PARCEL	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-31 07:15:56.433	2025-12-31 07:15:56.433	\N
5a5379f4-b0a6-4eeb-9e64-c3b925fe7a65	PROD003	OWN003	ACTIVE	AVAILABLE	CAT003	\N	\N	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	\N	\N	\N	\N	\N	\N	TAXABLE	45000	35000	42000	40000	\N	\N	\N	1	20	400	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Ocean Fresh Co.	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	COLD_CHAIN	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-31 07:15:56.434	2025-12-31 07:15:56.434	\N
053326cf-f86e-4b8d-ac90-4af9e3766da0	PROD004	OWN004	ACTIVE	AVAILABLE	CAT003	\N	\N	Premium Wagyu Beef Set	Premium Wagyu Beef Set	\N	\N	\N	\N	\N	\N	TAXABLE	120000	90000	110000	105000	\N	\N	\N	1	10	1050	PERCENTAGE	\N	NO	YES	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Premium Meats Ltd.	\N	\N	\N	\N	\N	\N	\N	\N	4	\N	\N	\N	\N	\N	\N	\N	COLD_CHAIN	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-31 07:15:56.437	2025-12-31 07:15:56.437	\N
79124b2b-1ac7-4f14-b87d-098a80d7fe53	PROD005	OWN005	ACTIVE	AVAILABLE	CAT004	\N	\N	Organic Vegetable Box (Large)	Organic Vegetable Box (Large)	\N	\N	\N	\N	\N	\N	TAXABLE	55000	40000	50000	48000	\N	\N	\N	1	30	480	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Farm Fresh Organics	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	COLD_CHAIN	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-31 07:15:56.439	2025-12-31 07:15:56.439	\N
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recipes (id, title, "authorId", "authorName", date_of_writing, views, status, thumbnail_url, content, ingredients, created_at, updated_at, is_active, category) FROM stdin;
ff8d82ec-44d3-4534-a9bc-e3b56288aa04	Classic Korean Kimchi Fried Rice	user021	USER10	2025-06-07 00:41:01.87	2411	active	https://example.com/thumbnails/recipe-1.jpg	A delicious and easy kimchi fried rice recipe with bacon and vegetables.	{Rice,Kimchi,Bacon,"Green onion","Sesame oil","Soy sauce",Egg}	2025-12-31 07:15:56.512	2025-12-31 07:15:56.512	t	RECIPE
056afcf6-43a6-489e-9b14-9b22d29d2b14	Homemade Italian Pasta Carbonara	user017	USER6	2025-01-02 19:49:08.145	929	active	https://example.com/thumbnails/recipe-2.jpg	Authentic Italian carbonara with eggs, pecorino cheese, and guanciale.	{Spaghetti,Eggs,"Pecorino cheese",Guanciale,"Black pepper"}	2025-12-31 07:15:56.514	2025-12-31 07:15:56.514	t	RECIPE
8cedc628-9267-4b9c-aafd-7fb97d1f1e9d	Healthy Buddha Bowl	user013	USER2	2025-01-29 16:27:18.817	627	active	https://example.com/thumbnails/recipe-3.jpg	A nutritious bowl packed with quinoa, roasted vegetables, and tahini dressing.	{Quinoa,"Sweet potato",Chickpeas,Kale,Avocado,Tahini,Lemon}	2025-12-31 07:15:56.515	2025-12-31 07:15:56.515	t	RECIPE
f3809a7b-45cc-4910-8845-2757bcff9741	Spicy Thai Green Curry	user020	USER9	2025-01-14 20:23:50.703	3029	active	https://example.com/thumbnails/recipe-4.jpg	Aromatic Thai green curry with chicken and vegetables in coconut milk.	{Chicken,"Green curry paste","Coconut milk","Thai basil","Bamboo shoots","Fish sauce"}	2025-12-31 07:15:56.516	2025-12-31 07:15:56.516	t	RECIPE
0a46fdba-8cf6-4cdf-b7de-fafe14b50ded	Japanese Ramen Bowl	user020	USER9	2025-08-04 20:50:34.081	515	active	https://example.com/thumbnails/recipe-5.jpg	Rich and flavorful ramen with pork belly, soft-boiled egg, and noodles.	{"Ramen noodles","Pork belly",Egg,"Green onion",Nori,"Miso paste","Chicken broth"}	2025-12-31 07:15:56.517	2025-12-31 07:15:56.517	t	RECIPE
068b8780-61e0-49b7-b3ef-501ee25e2c5d	Mediterranean Grilled Chicken	user015	USER4	2025-05-16 15:30:51.161	3087	active	https://example.com/thumbnails/recipe-6.jpg	Grilled chicken marinated in herbs and lemon, served with Greek salad.	{"Chicken breast","Olive oil",Lemon,Oregano,Garlic,Tomatoes,Cucumber,"Feta cheese"}	2025-12-31 07:15:56.521	2025-12-31 07:15:56.521	t	RECIPE
9ebaa7b2-caff-45f4-a6a7-d82861372e9b	Vegan Lentil Soup	user021	USER10	2025-10-13 06:41:10.695	2462	active	https://example.com/thumbnails/recipe-7.jpg	Hearty and nutritious lentil soup with vegetables and aromatic spices.	{"Red lentils",Carrots,Celery,Onion,Garlic,Cumin,"Vegetable broth"}	2025-12-31 07:15:56.522	2025-12-31 07:15:56.522	t	DAILY_LIFE
818bfe75-c205-43b7-b11a-47044a01666d	Classic French Croissant	user020	USER9	2025-03-26 15:50:29.104	1859	active	https://example.com/thumbnails/recipe-8.jpg	Buttery, flaky croissants made from scratch with laminated dough.	{Flour,Butter,Milk,Sugar,Salt,Yeast}	2025-12-31 07:15:56.523	2025-12-31 07:15:56.523	t	REVIEWS
\.


--
-- Data for Name: refresh_token_used; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_token_used (id, "refreshToken", "sessionId") FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, "createdAt", "updatedAt") FROM stdin;
93077290-7e6a-451f-853a-ad684ce0b62e	ADMIN	Administrator with full system access	2025-12-31 07:15:55.172	2025-12-31 07:15:55.172
0f5f19bb-ee9e-4e2b-bd67-6920f9d4222b	GENERAL_MANAGER	General Manager (총괄 담당자) - oversees all operations	2025-12-31 07:15:55.177	2025-12-31 07:15:55.177
a666313c-e360-4752-8f34-5a98ac9854cc	MANAGER	Manager (담당자) - manages specific areas	2025-12-31 07:15:55.178	2025-12-31 07:15:55.178
aeb946f0-e2a7-426c-9e03-f84b45e0f3f8	MD	MD - specialized management role	2025-12-31 07:15:55.18	2025-12-31 07:15:55.18
78341164-9d70-4ede-af28-86b02e199b2e	CS_MANAGER	CS Manager (CS 담당자) - customer service management	2025-12-31 07:15:55.182	2025-12-31 07:15:55.182
ec368a23-2988-4ff2-887f-688c441de243	USER	Basic user role	2025-12-31 07:15:55.183	2025-12-31 07:15:55.183
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, "userId", "refreshToken", ip, "expiredAt") FROM stdin;
05d13088-b02b-42be-94bd-e9924b00a345	user000	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyMDAwIiwidG9rZW5UeXBlIjoiUkVGUkVTSF9UT0tFTiIsInVzZXJuYW1lIjoiYWRtaW4xQGV4YW1wbGUuY29tIiwiZW1haWwiOiJhZG1pbjFAZXhhbXBsZS5jb20iLCJyb2xlcyI6WyJBRE1JTiJdLCJpYXQiOjE3NjczMzQ4MTYsImV4cCI6MTc2NzkzOTYxNn0.YoRmQmgAi3hMClwA8GpYAF1NnCNW3JDxo_zEctmxgzU	\N	2026-01-09 06:20:16
\.


--
-- Data for Name: user_memberships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_memberships (id, "userId", "membershipId", membership_name, membership_description, status, start_date, end_date, created_at, updated_at, updated_by_admin) FROM stdin;
77341cb4-da6f-4d63-89cb-8d7b22ed5ad2	user005	1a686aac-df12-49bd-a73b-d82dacbe1c2c	SILVER	Silver membership - Standard benefits package	normal	2024-01-12 07:56:47.669	2025-01-11 07:56:47.669	2025-12-31 07:15:56.409	2025-12-31 07:15:56.409	f
c0aca3ff-1570-4b24-a6bc-5d9de1b372f8	user006	79cdbf05-ce52-47b8-a2a4-0917649d3086	GOLD	Gold membership - Enhanced benefits and rewards	normal	2024-01-19 01:47:22.263	2025-01-18 01:47:22.263	2025-12-31 07:15:56.41	2025-12-31 07:15:56.41	f
35e75c8c-3503-42fa-8b5d-821bc826fde1	user007	79cdbf05-ce52-47b8-a2a4-0917649d3086	GOLD	Gold membership - Enhanced benefits and rewards	normal	2024-09-20 08:39:45.569	2025-09-20 08:39:45.569	2025-12-31 07:15:56.411	2025-12-31 07:15:56.411	f
acc953df-986a-42cd-9d99-4c9fd4708658	user008	c4f841c5-3acc-4ee6-aaa4-3ca139b17e0c	GENERAL	General membership - Entry level membership for users with less than 150000	suspended	2025-11-20 14:44:50.615	2026-11-20 14:44:50.615	2025-12-31 07:15:56.412	2025-12-31 07:15:56.412	f
aec1d054-d8c3-47ff-a1af-0b0cf123a207	user010	c4f841c5-3acc-4ee6-aaa4-3ca139b17e0c	GENERAL	General membership - Entry level membership for users with less than 150000	suspended	2024-07-07 00:58:43.222	2025-07-07 00:58:43.222	2025-12-31 07:15:56.414	2025-12-31 07:15:56.414	f
88d77b19-f98a-4555-a7f3-8a45fb73ee78	user011	1a686aac-df12-49bd-a73b-d82dacbe1c2c	SILVER	Silver membership - Standard benefits package	suspended	2025-08-29 06:55:06.36	2026-08-29 06:55:06.36	2025-12-31 07:15:56.415	2025-12-31 07:15:56.415	f
05bb8e80-cf70-4f83-81bc-1c4e9ee6f3f7	user013	e7276b95-d0f2-4374-967c-8defcdbf99bb	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	normal	2024-02-27 11:30:28.91	2025-02-26 11:30:28.91	2025-12-31 07:15:56.416	2025-12-31 07:15:56.416	f
bca0afb9-6a4a-45ac-950c-c4f1b053b7ae	user015	e7276b95-d0f2-4374-967c-8defcdbf99bb	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	normal	2024-10-23 08:38:59.386	2025-10-23 08:38:59.386	2025-12-31 07:15:56.418	2025-12-31 07:15:56.418	f
accef510-0186-4095-8017-2a769ac353a5	user017	79cdbf05-ce52-47b8-a2a4-0917649d3086	GOLD	Gold membership - Enhanced benefits and rewards	suspended	2024-11-23 23:45:43.751	2025-11-23 23:45:43.751	2025-12-31 07:15:56.421	2025-12-31 07:15:56.421	f
1791a003-f8e0-4975-b238-961ccffff33e	user021	79cdbf05-ce52-47b8-a2a4-0917649d3086	GOLD	Gold membership - Enhanced benefits and rewards	normal	2024-08-24 15:13:14.123	2025-08-24 15:13:14.123	2025-12-31 07:15:56.424	2025-12-31 07:15:56.424	f
f74b378f-8d95-4860-8b33-663e38fc0c59	user014	e11341eb-7c17-416b-9fd9-332bbaf2f338	VIP	Very Important Person - Premium membership with special privileges	expired	2025-12-19 18:37:10.651	2025-12-31 19:21:54.203	2025-12-31 07:15:56.417	2025-12-31 19:21:54.203	f
7aa212b4-ae86-42e7-a023-ee7706e04c66	user020	79cdbf05-ce52-47b8-a2a4-0917649d3086	GOLD	Gold membership - Enhanced benefits and rewards	expired	2025-11-05 08:38:27.608	2025-12-31 19:21:54.139	2025-12-31 07:15:56.423	2025-12-31 19:21:54.139	f
1f044723-ee58-4c8b-af7e-a97b94b43bd2	user016	e7276b95-d0f2-4374-967c-8defcdbf99bb	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	expired	2025-03-08 20:06:38.685	2025-12-31 19:21:54.219	2025-12-31 07:15:56.42	2025-12-31 19:21:54.219	f
c03af83d-efc7-475c-b4db-b516cc692fa0	user000	1a686aac-df12-49bd-a73b-d82dacbe1c2c	SILVER	Silver membership - Standard benefits package	expired	2025-08-19 08:25:35.826	2025-12-31 19:21:54.176	2025-12-31 07:15:56.4	2025-12-31 19:21:54.176	f
9d573f62-2985-478f-a2d7-8fb3caaa9b1d	user003	c4f841c5-3acc-4ee6-aaa4-3ca139b17e0c	GENERAL	General membership - Entry level membership for users with less than 150000	normal	2024-11-08 10:47:22.852	2026-12-31 19:21:54.287	2025-12-31 07:15:56.407	2025-12-31 19:21:54.287	f
bee89c9f-0e2a-42e7-bbdc-d69891198da4	user019	e11341eb-7c17-416b-9fd9-332bbaf2f338	VIP	Very Important Person - Premium membership with special privileges	expired	2025-01-03 08:08:10.325	2025-12-31 19:21:54.305	2025-12-31 07:15:56.422	2025-12-31 19:21:54.305	f
b95ad4e3-6a20-49e8-89ed-0b6b7b841250	user004	1a686aac-df12-49bd-a73b-d82dacbe1c2c	SILVER	Silver membership - Standard benefits package	expired	2025-10-19 15:27:16.933	2025-12-31 19:21:54.34	2025-12-31 07:15:56.408	2025-12-31 19:21:54.34	f
86f4ff06-355e-41e9-8ed0-fc9bb4ade4de	user009	c4f841c5-3acc-4ee6-aaa4-3ca139b17e0c	GENERAL	General membership - Entry level membership for users with less than 150000	normal	2024-09-03 12:23:54.894	2026-12-31 19:21:54.335	2025-12-31 07:15:56.413	2025-12-31 19:21:54.335	f
2bc42da3-9555-4d4c-ade7-4c1387c9563d	user001	c4f841c5-3acc-4ee6-aaa4-3ca139b17e0c	GENERAL	General membership - Entry level membership for users with less than 150000	normal	2024-11-23 17:43:03.423	2026-12-31 19:21:54.381	2025-12-31 07:15:56.404	2025-12-31 19:21:54.381	f
9da65984-885b-4706-986f-c000b23c284b	user018	e7276b95-d0f2-4374-967c-8defcdbf99bb	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	expired	2025-12-06 01:24:38.335	2025-12-31 19:21:54.355	2025-12-31 07:15:56.421	2025-12-31 19:21:54.355	f
9d5fbd61-38d4-4722-8bdd-ed86155d4277	user002	79cdbf05-ce52-47b8-a2a4-0917649d3086	GOLD	Gold membership - Enhanced benefits and rewards	expired	2025-08-17 23:53:03.779	2025-12-31 19:21:54.397	2025-12-31 07:15:56.406	2025-12-31 19:21:54.397	f
85c49bf4-492b-4132-9797-f8e52fcdbd4c	user012	c4f841c5-3acc-4ee6-aaa4-3ca139b17e0c	GENERAL	General membership - Entry level membership for users with less than 150000	expired	2025-07-05 05:20:36.546	2025-12-31 19:21:54.421	2025-12-31 07:15:56.415	2025-12-31 19:21:54.421	f
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles ("userId", "roleId", "createdAt") FROM stdin;
user000	93077290-7e6a-451f-853a-ad684ce0b62e	2025-12-31 07:15:56.389
user001	93077290-7e6a-451f-853a-ad684ce0b62e	2025-12-31 07:15:56.389
user002	0f5f19bb-ee9e-4e2b-bd67-6920f9d4222b	2025-12-31 07:15:56.389
user003	0f5f19bb-ee9e-4e2b-bd67-6920f9d4222b	2025-12-31 07:15:56.389
user004	a666313c-e360-4752-8f34-5a98ac9854cc	2025-12-31 07:15:56.389
user005	a666313c-e360-4752-8f34-5a98ac9854cc	2025-12-31 07:15:56.389
user006	a666313c-e360-4752-8f34-5a98ac9854cc	2025-12-31 07:15:56.389
user007	aeb946f0-e2a7-426c-9e03-f84b45e0f3f8	2025-12-31 07:15:56.389
user008	aeb946f0-e2a7-426c-9e03-f84b45e0f3f8	2025-12-31 07:15:56.389
user009	78341164-9d70-4ede-af28-86b02e199b2e	2025-12-31 07:15:56.389
user010	78341164-9d70-4ede-af28-86b02e199b2e	2025-12-31 07:15:56.389
user011	78341164-9d70-4ede-af28-86b02e199b2e	2025-12-31 07:15:56.389
user012	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user013	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user014	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user015	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user016	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user017	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user018	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user019	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user020	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
user021	ec368a23-2988-4ff2-887f-688c441de243	2025-12-31 07:15:56.389
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, password, name, "membershipLevel", age, email, phone_number, total_used_points, available_points, registration_date, dormancy_date, withdrawal_date, withdrawal_type, reason_for_withdrawal, created_at, updated_at, total_purchase_amount, dashboard_access, member_access, product_access, order_access, recipe_access, banner_access) FROM stdin;
user021	$2b$10$MJtSxPx7527dknIJXopSJOygglPu6iqEOoeTR65tPib1ZqkUWY6kC	USER10	\N	44	user10@example.com	010-1021-5021	45069	15639	2025-09-08	\N	\N	\N	\N	2025-12-31 07:15:56.383	2026-01-01 19:13:45.341	247500	t	f	t	t	t	f
user012	$2b$10$Lx0FFyD7uU4vitEIYxxT9ejFqLPrUq8oo.xu66TFiUpQOLN1IbzYS	USER1	\N	22	user1@example.com	010-1012-5012	48217	11821	2025-11-27	\N	\N	\N	\N	2025-12-31 07:15:55.904	2026-01-01 19:13:45.349	210000	t	f	t	t	t	f
user020	$2b$10$SKFiMmwCWyaaunpUDVTSSu98l3ms9p4T4gizGOfdRM6tHatndNQey	USER9	\N	64	user9@example.com	010-1020-5020	489	5686	2024-03-31	\N	\N	\N	\N	2025-12-31 07:15:56.327	2026-01-01 19:13:45.129	240000	t	f	t	t	t	f
user014	$2b$10$iw9SLwcZF9eYIbbL.XzjCuY.z7V.WHuqPle0/NvPYtqqRj8Q8xT.u	USER3	\N	34	user3@example.com	010-1014-5014	24438	18230	2024-07-30	\N	\N	\N	\N	2025-12-31 07:15:56.006	2026-01-01 19:13:45.162	112000	t	f	t	t	t	f
user017	$2b$10$XkvFdpZgKZhV3VYVP.ElNeoM6RnTkpetdAO4YKYKjVxubeLHerCKC	USER6	\N	28	user6@example.com	010-1017-5017	4273	19489	2024-01-11	\N	\N	\N	\N	2025-12-31 07:15:56.167	2026-01-01 19:13:45.199	217000	t	f	t	t	t	f
user019	$2b$10$0EHeUml7SudEINq76hPw0ezubi1PSticYdtvasmwUBnd3wPpXL/V2	USER8	\N	58	user8@example.com	010-1019-5019	37241	7581	2025-09-10	\N	\N	\N	\N	2025-12-31 07:15:56.273	2026-01-01 19:13:45.25	13000	t	f	t	t	t	f
user000	$2b$10$PX2v.i3f6mTUUi1rX.CNu.b1b582g5Z.oDy5UfWZW0Ji1WwR8UFFK	ADMIN1	\N	35	admin1@example.com	010-1000-5000	18910	8057	2025-10-27	\N	\N	\N	\N	2025-12-31 07:15:55.25	2026-01-01 19:13:45.141	0	t	t	t	t	t	t
user001	$2b$10$kENMcAR3zHiXd7eTKnX3lO/UtNlw4Cu1Uu28zqEKT/bpeP2NMn8SW	ADMIN2	GENERAL	51	admin2@example.com	010-1001-5001	34078	9851	2024-06-02	\N	\N	\N	\N	2025-12-31 07:15:55.304	2026-01-01 19:13:45.323	0	t	t	t	t	t	t
user016	$2b$10$lKP/1cFbSgAhXhxiuZ.5PupShRhg/ZU1/EKXy5L7c3jRlKcvLh/L6	USER5	\N	62	user5@example.com	010-1016-5016	15272	9608	2025-05-13	\N	\N	\N	\N	2025-12-31 07:15:56.113	2026-01-01 19:13:45.178	52000	t	f	t	t	t	f
user010	$2b$10$wvqHEcFmmLBlL2VNe0F0MeXau/OGWUTaWzSgtj9kvnGpqyHdbyMzm	CS_MANAGER2	\N	43	cs_manager2@example.com	010-1010-5010	28569	5940	2024-12-01	\N	\N	\N	\N	2025-12-31 07:15:55.795	2026-01-01 19:13:45.213	0	t	t	t	t	t	f
user005	$2b$10$jPZO0/4K0aKsvzKeV0Qt7eVcS1LpqMsbTEwxoV47G9Sd4KmS2GoWW	MANAGER2	\N	62	manager2@example.com	010-1005-5005	3149	1296	2025-09-07	\N	\N	\N	\N	2025-12-31 07:15:55.512	2026-01-01 19:13:45.149	0	t	t	f	t	t	f
user011	$2b$10$QaC4wzhofxoxOHHB7D4moeQoHhqP8NJQgGLEPWfVnCQnStCQHscTW	CS_MANAGER3	\N	65	cs_manager3@example.com	010-1011-5011	2811	7378	2025-04-26	\N	\N	\N	\N	2025-12-31 07:15:55.851	2026-01-01 19:13:45.328	0	t	t	t	t	t	f
user007	$2b$10$2K46NXr/VggulSXzaB28Ien/Cl0ONngZ2VXhe/7gA4UysMJp1OY6O	MD1	\N	52	md1@example.com	010-1007-5007	15481	1828	2024-08-25	\N	\N	\N	\N	2025-12-31 07:15:55.62	2026-01-01 19:13:45.222	0	t	t	t	t	t	t
user009	$2b$10$Sjwr3OrCNAFouME8K6KPKuKmChig4MqBcN6xwscBkPzfLitgDV9jO	CS_MANAGER1	GENERAL	52	cs_manager1@example.com	010-1009-5009	4134	2381	2024-01-12	\N	\N	\N	\N	2025-12-31 07:15:55.739	2026-01-01 19:13:45.289	0	t	t	t	t	t	f
user008	$2b$10$v/m3tj074iHOjlzLqSmnLuBWNXuEZdw9fwdjQjenVGnqGOCiq12yC	MD2	\N	33	md2@example.com	010-1008-5008	25498	15042	2025-11-27	\N	\N	\N	\N	2025-12-31 07:15:55.675	2026-01-01 19:13:45.189	0	t	t	t	t	t	t
user003	$2b$10$vaibxcJ6h2l9Co/0.XLw9uiM2.KKqgNUnGRT0G3qvDCHH24U9VMuq	GENERAL_MANAGER2	GENERAL	38	general_manager2@example.com	010-1003-5003	8484	2917	2025-12-23	\N	\N	\N	\N	2025-12-31 07:15:55.408	2026-01-01 19:13:45.243	0	t	t	t	t	t	t
user013	$2b$10$4P1dAN1UyEEpDe0.FCWxK.W32peJ9NTWExZewocudvMAieWY42wFW	USER2	\N	35	user2@example.com	010-1013-5013	42108	17325	2024-06-07	\N	\N	\N	\N	2025-12-31 07:15:55.955	2026-01-01 19:13:45.305	870000	t	f	t	t	t	f
user006	$2b$10$4EtaLShzjJ8aYbPLbr2SxOa6fsCdNdgjqUc.iM2bWxqcg2hGHqvh6	MANAGER3	\N	43	manager3@example.com	010-1006-5006	42430	12097	2025-01-19	\N	\N	\N	\N	2025-12-31 07:15:55.565	2026-01-01 19:13:45.244	0	t	t	f	t	t	f
user002	$2b$10$m3j4yByI8/AMEC7vFdFFo.2/c8baw6VRQDnG.5LlLaUJXjhooReQa	GENERAL_MANAGER1	\N	23	general_manager1@example.com	010-1002-5002	8648	7755	2024-12-30	\N	\N	\N	\N	2025-12-31 07:15:55.356	2026-01-01 19:13:45.332	0	t	t	t	t	t	t
user015	$2b$10$20u1cW3QI.ivA1S9JaWnS.M6xBCKfM2/LK1v05JAE0UsF7u7UJFTm	USER4	\N	45	user4@example.com	010-1015-5015	44980	7738	2025-04-28	\N	\N	\N	\N	2025-12-31 07:15:56.06	2026-01-01 19:13:45.263	713000	t	f	t	t	t	f
user004	$2b$10$Q0e3lWE13KVkxd0PgYk4Fua7w6b7.BOzpoV9WAtbI3q5Z9RatpLw6	MANAGER1	\N	39	manager1@example.com	010-1004-5004	44136	16428	2024-03-20	\N	\N	\N	\N	2025-12-31 07:15:55.459	2026-01-01 19:13:45.29	0	t	t	t	t	t	t
user018	$2b$10$nr2s5O7rXZsUhmmIjJWZJ.Dj0doOCmy5L3RW/ebWbo7iS8q71bCOa	USER7	\N	22	user7@example.com	010-1018-5018	33089	978	2025-01-20	\N	\N	\N	\N	2025-12-31 07:15:56.22	2026-01-01 19:13:45.293	420000	t	f	t	t	t	f
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (product_category_number);


--
-- Name: coupon_histories coupon_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: points points_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_pkey PRIMARY KEY (id);


--
-- Name: product_discounts product_discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_discounts
    ADD CONSTRAINT product_discounts_pkey PRIMARY KEY (id);


--
-- Name: product_special_offers product_special_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_special_offers
    ADD CONSTRAINT product_special_offers_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: refresh_token_used refresh_token_used_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_token_used
    ADD CONSTRAINT refresh_token_used_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: user_memberships user_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT user_memberships_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY ("userId", "roleId");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: banners_display_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_display_order_idx ON public.banners USING btree (display_order);


--
-- Name: banners_start_date_end_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_start_date_end_date_idx ON public.banners USING btree (start_date, end_date);


--
-- Name: banners_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_status_idx ON public.banners USING btree (status);


--
-- Name: banners_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_type_idx ON public.banners USING btree (type);


--
-- Name: cart_items_cart_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_items_cart_id_idx ON public.cart_items USING btree (cart_id);


--
-- Name: cart_items_cart_id_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cart_items_cart_id_product_id_key ON public.cart_items USING btree (cart_id, product_id);


--
-- Name: cart_items_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_items_product_id_idx ON public.cart_items USING btree (product_id);


--
-- Name: carts_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX carts_status_idx ON public.carts USING btree (status);


--
-- Name: carts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX carts_user_id_idx ON public.carts USING btree (user_id);


--
-- Name: carts_user_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX carts_user_id_key ON public.carts USING btree (user_id);


--
-- Name: categories_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX categories_name_key ON public.categories USING btree (name);


--
-- Name: categories_product_category_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX categories_product_category_number_key ON public.categories USING btree (product_category_number);


--
-- Name: coupon_histories_coupon_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_coupon_id_idx ON public.coupon_histories USING btree (coupon_id);


--
-- Name: coupon_histories_issued_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_issued_at_idx ON public.coupon_histories USING btree (issued_at);


--
-- Name: coupon_histories_order_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_order_id_idx ON public.coupon_histories USING btree (order_id);


--
-- Name: coupon_histories_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_status_idx ON public.coupon_histories USING btree (status);


--
-- Name: coupon_histories_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_user_id_idx ON public.coupon_histories USING btree (user_id);


--
-- Name: coupons_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupons_code_idx ON public.coupons USING btree (code);


--
-- Name: coupons_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX coupons_code_key ON public.coupons USING btree (code);


--
-- Name: coupons_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupons_is_active_idx ON public.coupons USING btree (is_active);


--
-- Name: coupons_start_date_end_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupons_start_date_end_date_idx ON public.coupons USING btree (start_date, end_date);


--
-- Name: memberships_min_price_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX memberships_min_price_idx ON public.memberships USING btree (min_price);


--
-- Name: memberships_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX memberships_name_idx ON public.memberships USING btree (name);


--
-- Name: memberships_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX memberships_name_key ON public.memberships USING btree (name);


--
-- Name: orders_cart_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_cart_id_idx ON public.orders USING btree (cart_id);


--
-- Name: points_user_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX points_user_id_key ON public.points USING btree (user_id);


--
-- Name: product_discounts_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_discounts_product_id_key ON public.product_discounts USING btree (product_id);


--
-- Name: product_special_offers_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_special_offers_product_id_key ON public.product_special_offers USING btree (product_id);


--
-- Name: recipes_authorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "recipes_authorId_idx" ON public.recipes USING btree ("authorId");


--
-- Name: recipes_date_of_writing_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recipes_date_of_writing_idx ON public.recipes USING btree (date_of_writing);


--
-- Name: recipes_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recipes_status_idx ON public.recipes USING btree (status);


--
-- Name: refresh_token_used_refreshToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "refresh_token_used_refreshToken_key" ON public.refresh_token_used USING btree ("refreshToken");


--
-- Name: refresh_token_used_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "refresh_token_used_sessionId_idx" ON public.refresh_token_used USING btree ("sessionId");


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: sessions_refreshToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sessions_refreshToken_key" ON public.sessions USING btree ("refreshToken");


--
-- Name: sessions_userId_expiredAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sessions_userId_expiredAt_idx" ON public.sessions USING btree ("userId", "expiredAt");


--
-- Name: user_memberships_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_memberships_id_key ON public.user_memberships USING btree (id);


--
-- Name: user_memberships_membershipId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_memberships_membershipId_idx" ON public.user_memberships USING btree ("membershipId");


--
-- Name: user_memberships_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_memberships_userId_idx" ON public.user_memberships USING btree ("userId");


--
-- Name: user_memberships_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_memberships_userId_key" ON public.user_memberships USING btree ("userId");


--
-- Name: user_memberships_userId_membershipId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_memberships_userId_membershipId_idx" ON public.user_memberships USING btree ("userId", "membershipId");


--
-- Name: user_roles_roleId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_roles_roleId_idx" ON public.user_roles USING btree ("roleId");


--
-- Name: user_roles_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_roles_userId_idx" ON public.user_roles USING btree ("userId");


--
-- Name: users_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_id_key ON public.users USING btree (id);


--
-- Name: banners banners_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_items cart_items_cart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_cart_id_fkey FOREIGN KEY (cart_id) REFERENCES public.carts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_items cart_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: carts carts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coupon_histories coupon_histories_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coupon_histories coupon_histories_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: coupon_histories coupon_histories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_orderer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_orderer_id_fkey FOREIGN KEY (orderer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: points points_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_discounts product_discounts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_discounts
    ADD CONSTRAINT product_discounts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_special_offers product_special_offers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_special_offers
    ADD CONSTRAINT product_special_offers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_product_category_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_category_number_fkey FOREIGN KEY (product_category_number) REFERENCES public.categories(product_category_number) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: recipes recipes_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT "recipes_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: refresh_token_used refresh_token_used_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_token_used
    ADD CONSTRAINT "refresh_token_used_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_memberships user_memberships_membershipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT "user_memberships_membershipId_fkey" FOREIGN KEY ("membershipId") REFERENCES public.memberships(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_memberships user_memberships_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT "user_memberships_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict oXVbUPcpKDjma1FM0IQS5uqa6Zo2bM3N1LwHefm1Cn3uP200bB9swnY2whjWuUX

