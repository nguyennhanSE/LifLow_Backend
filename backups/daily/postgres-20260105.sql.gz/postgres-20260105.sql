--
-- PostgreSQL database dump
--

\restrict FoaJ6EfGgApeWueOYygvKmHHpJpOcUcWJAvcZ3VVHyVRa0eqf4c63wqRght4sQk

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: BannerStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BannerStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SCHEDULED'
);


ALTER TYPE public."BannerStatus" OWNER TO postgres;

--
-- Name: BannerType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BannerType" AS ENUM (
    'ALL',
    'MAIN_PRODUCTS',
    'CATEGORY',
    'FOOTER',
    'CONTENT_HERO',
    'SPECIAL_PRICE'
);


ALTER TYPE public."BannerType" OWNER TO postgres;

--
-- Name: CartStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CartStatus" AS ENUM (
    'ACTIVE',
    'CHECKED_OUT'
);


ALTER TYPE public."CartStatus" OWNER TO postgres;

--
-- Name: CategoryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CategoryType" AS ENUM (
    'LIVESTOCK',
    'CONVENIENCE_FOOD',
    'FISHERIES',
    'SIDE_DISH'
);


ALTER TYPE public."CategoryType" OWNER TO postgres;

--
-- Name: CouponHistoryStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CouponHistoryStatus" AS ENUM (
    'ISSUED',
    'USED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."CouponHistoryStatus" OWNER TO postgres;

--
-- Name: CouponType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CouponType" AS ENUM (
    'PERCENT',
    'AMOUNT'
);


ALTER TYPE public."CouponType" OWNER TO postgres;

--
-- Name: OrderSituation; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderSituation" AS ENUM (
    'ORDER_NEW',
    'ORDER_PAYMENT_PENDING',
    'ORDER_PAYMENT_COMPLETED',
    'ORDER_IN_PREPARE',
    'ORDER_BEING_SHIPPED',
    'ORDER_SHIPPED',
    'ORDER_CANCELLED',
    'ORDER_RETURNED'
);


ALTER TYPE public."OrderSituation" OWNER TO postgres;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'SUCCESS',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."PaymentStatus" OWNER TO postgres;

--
-- Name: RecipeCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RecipeCategory" AS ENUM (
    'RECIPE',
    'REVIEWS',
    'DAILY_LIFE'
);


ALTER TYPE public."RecipeCategory" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: banners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banners (
    id text NOT NULL,
    product_category_number text,
    product_id text,
    type public."BannerType" NOT NULL,
    status public."BannerStatus" DEFAULT 'ACTIVE'::public."BannerStatus" NOT NULL,
    title character varying(255),
    badge_text character varying(100),
    main_text text,
    cta_button_text character varying(100),
    cta_button_url character varying(500),
    image_url text NOT NULL,
    mobile_image_url text,
    display_order integer DEFAULT 0 NOT NULL,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.banners OWNER TO postgres;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    id text NOT NULL,
    cart_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    sale_price integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: carts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carts (
    id text NOT NULL,
    user_id text NOT NULL,
    status public."CartStatus" DEFAULT 'ACTIVE'::public."CartStatus" NOT NULL,
    total_amount integer DEFAULT 0 NOT NULL,
    checked_out_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.carts OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    product_category_number character varying(50) NOT NULL,
    name public."CategoryType" NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: coupon_histories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupon_histories (
    id text NOT NULL,
    coupon_id text NOT NULL,
    user_id text NOT NULL,
    order_id text,
    status public."CouponHistoryStatus" DEFAULT 'ISSUED'::public."CouponHistoryStatus" NOT NULL,
    issued_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    used_at timestamp(3) without time zone,
    expired_at timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone,
    discount_applied_amount integer,
    purchase_amount_at_use integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.coupon_histories OWNER TO postgres;

--
-- Name: coupons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupons (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    type public."CouponType" NOT NULL,
    discount_rate integer,
    discount_amount integer,
    min_purchase_amount integer DEFAULT 0 NOT NULL,
    max_discount_amount integer,
    image_url text,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_auto_issue boolean DEFAULT false NOT NULL,
    auto_issue_day_of_month timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    target_grades text[] DEFAULT ARRAY[]::text[]
);


ALTER TABLE public.coupons OWNER TO postgres;

--
-- Name: memberships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memberships (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    min_price integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone
);


ALTER TABLE public.memberships OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    order_number text DEFAULT ''::text NOT NULL,
    item_wise_order_number text DEFAULT ''::text NOT NULL,
    total_order_amount integer NOT NULL,
    total_payment_amount integer NOT NULL,
    product_id text NOT NULL,
    product_name text DEFAULT ''::text NOT NULL,
    product_name_with_options text DEFAULT ''::text NOT NULL,
    quantity integer NOT NULL,
    recipient text DEFAULT ''::text NOT NULL,
    recipient_address_full text DEFAULT ''::text NOT NULL,
    recipient_postal_code integer NOT NULL,
    recipient_mobile_phone text DEFAULT ''::text NOT NULL,
    recipient_phone_number text DEFAULT ''::text NOT NULL,
    delivery_message text DEFAULT ''::text NOT NULL,
    sale_price integer NOT NULL,
    payment_type text DEFAULT ''::text NOT NULL,
    payment_method text DEFAULT ''::text NOT NULL,
    order_date text DEFAULT ''::text NOT NULL,
    orderer_name text DEFAULT ''::text NOT NULL,
    orderer_mobile_phone text DEFAULT ''::text NOT NULL,
    orderer_id text,
    desired_delivery_date text DEFAULT ''::text NOT NULL,
    membership_level_at_order_time text DEFAULT ''::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    situation public."OrderSituation",
    courier_company text,
    invoice_number text
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    user_id text NOT NULL,
    amount integer NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: points; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.points (
    id text NOT NULL,
    date character varying(50),
    user_id character varying(50),
    membership_level character varying(50),
    content character varying(50),
    order_number character varying(50),
    points_type character varying(50),
    available_points_increase integer,
    available_points_deduction integer,
    available_points_balance integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.points OWNER TO postgres;

--
-- Name: product_discounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_discounts (
    id text NOT NULL,
    status boolean DEFAULT false NOT NULL,
    product_id text NOT NULL,
    discount_rate integer NOT NULL,
    discount_start_date timestamp(3) without time zone,
    discount_end_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.product_discounts OWNER TO postgres;

--
-- Name: product_inquiries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_inquiries (
    id text NOT NULL,
    product_id text NOT NULL,
    author_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    content text NOT NULL,
    title text NOT NULL
);


ALTER TABLE public.product_inquiries OWNER TO postgres;

--
-- Name: product_inquiry_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_inquiry_answers (
    id text NOT NULL,
    inquiry_id text NOT NULL,
    answer text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.product_inquiry_answers OWNER TO postgres;

--
-- Name: product_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_reviews (
    id text NOT NULL,
    product_id text NOT NULL,
    author_id text NOT NULL,
    review text NOT NULL,
    rating double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    image_url text
);


ALTER TABLE public.product_reviews OWNER TO postgres;

--
-- Name: product_special_offers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_special_offers (
    id text NOT NULL,
    status boolean DEFAULT false NOT NULL,
    product_id text NOT NULL,
    discount_amount integer NOT NULL,
    special_price_applied integer,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone,
    updated_at timestamp(3) without time zone
);


ALTER TABLE public.product_special_offers OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    product_code text,
    own_product_code text,
    display_status text DEFAULT 'ACTIVE'::text,
    sale_status text,
    product_category_number text,
    product_category_new_product_area text,
    product_category_recommended_product_area text,
    product_name character varying(128),
    english_product_name text,
    product_name_for_management text,
    supplier_product_name text,
    model_name text,
    product_summary_description text,
    product_brief_description text,
    search_keyword_setting text,
    tax_classification text,
    consumer_price integer,
    supply_price integer,
    product_price integer,
    sale_price integer,
    use_sale_price_alternative_text text,
    sale_price_alternative_text text,
    order_quantity_limit_criteria text,
    min_order_quantity integer,
    max_order_quantity integer,
    reward_points integer,
    reward_points_classification text,
    common_event_info text,
    adult_verification text,
    option_usage text,
    item_composition_method text,
    option_display_method text,
    option_set_name text,
    option_input text,
    option_style text,
    button_image_setting text,
    color_setting text,
    required_or_not text,
    out_of_stock_display_text text,
    additional_input_option text,
    additional_input_option_name text,
    additional_input_option_required_or_not text,
    input_character_count text,
    image_registration_detail text,
    image_registration_list text,
    image_registration_small_list text,
    image_registration_thumbnail text,
    manufacturer text,
    supplier text,
    brand text,
    trend text,
    own_classification_code text,
    manufacturing_date text,
    release_date text,
    validity_period_usage text,
    validity_period text,
    origin integer,
    product_volume text,
    volume_weight text,
    product_payment_guide text,
    product_delivery_guide text,
    exchange_return_guide text,
    service_inquiry_guide text,
    delivery_info text,
    delivery_method text,
    domestic_overseas_delivery text,
    delivery_area text,
    delivery_fee_prepayment_setting text,
    delivery_period text,
    delivery_fee_classification text,
    delivery_fee_input text,
    product_classification_customs text,
    product_material text,
    english_product_material_customs text,
    fabric_customs text,
    seo_search_engine_exposure_setting text,
    seo_title text,
    seo_author text,
    seo_description text,
    seo_keywords text,
    seo_product_image_alt_text text,
    individual_payment_method_setting text,
    product_delivery_type_code text,
    store_pickup_setting text,
    product_total_weight integer,
    hs_code bigint,
    additional_item_01_today_departure_delivery_usage text,
    additional_item_02_today_departure_delivery_time text,
    additional_item_03_storage_method text,
    additional_item_04_origin text,
    additional_item_05_event text,
    additional_item_06_parcel_delivery text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    cta_button_url character varying(500)
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: recipes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipes (
    id text NOT NULL,
    title character varying(255) NOT NULL,
    "authorId" text,
    "authorName" character varying(100) NOT NULL,
    date_of_writing timestamp(3) without time zone NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    thumbnail_url text,
    content text NOT NULL,
    ingredients text[],
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    category public."RecipeCategory" NOT NULL
);


ALTER TABLE public.recipes OWNER TO postgres;

--
-- Name: refresh_token_used; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_token_used (
    id text NOT NULL,
    "refreshToken" text NOT NULL,
    "sessionId" text NOT NULL
);


ALTER TABLE public.refresh_token_used OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "refreshToken" text NOT NULL,
    ip text,
    "expiredAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: user_memberships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_memberships (
    id text NOT NULL,
    "userId" text NOT NULL,
    "membershipId" text NOT NULL,
    membership_name text NOT NULL,
    membership_description text NOT NULL,
    status text DEFAULT 'normal'::text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone,
    updated_by_admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_memberships OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    "userId" text NOT NULL,
    "roleId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    password text,
    name text NOT NULL,
    "membershipLevel" text,
    age integer,
    email text NOT NULL,
    phone_number text NOT NULL,
    total_used_points integer DEFAULT 0 NOT NULL,
    available_points integer DEFAULT 0 NOT NULL,
    registration_date text NOT NULL,
    dormancy_date text,
    withdrawal_date text,
    withdrawal_type text,
    reason_for_withdrawal text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(3) without time zone,
    total_purchase_amount integer DEFAULT 0 NOT NULL,
    dashboard_access boolean DEFAULT false NOT NULL,
    member_access boolean DEFAULT false NOT NULL,
    product_access boolean DEFAULT false NOT NULL,
    order_access boolean DEFAULT false NOT NULL,
    recipe_access boolean DEFAULT false NOT NULL,
    banner_access boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
0c2063bb-c42f-4d80-a0b4-01a6f90451aa	b47033e772b8d795d97824b56627fd2e6f9d8d6b624ce12cdb98d07520a6e5c3	2026-01-05 04:50:25.124047+00	20251226054111_init	\N	\N	2026-01-05 04:50:25.023879+00	1
b3ecb94b-796b-4710-aec9-0791d394d149	47a21d9cb213edcd4259347e6d9f2f49d274f1192f64bfdf9b07781651b94036	2026-01-05 04:50:25.126188+00	20251226061650_adjust_type_3	\N	\N	2026-01-05 04:50:25.124682+00	1
7d4f5cf8-e86b-4a0f-b258-5df0545fdc3d	b5745b00e89a834f4ac5100d4ef602e7bab63839fef5201748aa7bbf36003fcf	2026-01-05 04:50:25.132011+00	20251230062011_adjust_category	\N	\N	2026-01-05 04:50:25.126614+00	1
ffe0e285-f08f-4b12-a1f9-37358d1504d5	862d0b46d0b1e634e9e22c06c4a2fe0bf21d71554c3c46176281554619b0dd85	2026-01-05 04:50:25.13423+00	20251230062215_adjust_banner	\N	\N	2026-01-05 04:50:25.132598+00	1
2a142111-e428-4028-a575-0545bdfe3f90	48a4007df3a7f540d957a8544a1f579a81ebd34a161a45a10f34573ee9abb0c4	2026-01-05 04:50:25.141698+00	20251230110310_refactor_recipe	\N	\N	2026-01-05 04:50:25.134757+00	1
b45473f9-fc5f-4712-bf77-d071fbb76b15	d69a3b97545d3c7010d77efac89863c1ddadb4f069f4bd646aa23b850f938eaf	2026-01-05 04:50:25.148895+00	20251231092547_add_cart	\N	\N	2026-01-05 04:50:25.142264+00	1
685a74b6-8869-4f7b-8b5e-6f784d6da348	8e4a70effc3ad35ec05d935dae588d991d57285dc60a8c20f79eae178fe2fbfe	2026-01-05 04:50:25.151109+00	20260104192843_add_constraint_order	\N	\N	2026-01-05 04:50:25.149597+00	1
a61f4ebc-b882-46b6-a0e0-73820cdc1ec8	21868867a42da20b0b7cd06bcaae8f329b94e94a0864b18c4b6568bdba1807e1	2026-01-05 04:50:25.153069+00	20260104195315_change_coupon_target_grades	\N	\N	2026-01-05 04:50:25.151521+00	1
01d2ebdb-de32-4fc9-8990-4c6a5d58aa6a	20df7bee3808a73e1a5a4e8a6f542410bb5d83570fb8523c05efa9e38b2eb452	2026-01-05 04:50:25.165792+00	20260105044902_add_product_reviews_inquiries	\N	\N	2026-01-05 04:50:25.153517+00	1
7fcf1666-eeca-43da-aebd-2f2eb89a0f23	e7e32ee7097ac310953f442559199592de12c745330c44d8c111949fed0ed0a5	2026-01-05 06:58:58.385514+00	20260105065858_add_image_review	\N	\N	2026-01-05 06:58:58.382268+00	1
766e0cd4-5483-4e2a-82e8-2327fc28f172	02d4420eccf98a17a9601154014da9feb7fd3f789e073a3f6bb0f4bf4c276f19	2026-01-05 08:35:10.157911+00	20260105083510_change	\N	\N	2026-01-05 08:35:10.151387+00	1
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banners (id, product_category_number, product_id, type, status, title, badge_text, main_text, cta_button_text, cta_button_url, image_url, mobile_image_url, display_order, start_date, end_date, created_at, updated_at) FROM stdin;
60652748-9bf6-46e9-a5e4-2c7ea12bb551	CAT001	db7b5939-54e9-4520-a8e5-c2fd78c67bd4	MAIN_PRODUCTS	ACTIVE	Premium Quality for Your Kitchen	Best Seller	Discover our finest selection of premium organic olive oil	Shop Now	/products/db7b5939-54e9-4520-a8e5-c2fd78c67bd4	https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=1200	https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800	1	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.802	2026-01-05 04:51:10.802
f6901eca-f3fc-4324-93e5-1f2d96f18c33	\N	\N	CATEGORY	ACTIVE	Shop Everything You Need	All Products	Browse our complete catalog of premium products	Shop All	/products	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800	2	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.804	2026-01-05 04:51:10.804
386f4321-3b0e-4d39-9df3-a7678e080ed5	CAT001	\N	CATEGORY	ACTIVE	Explore Fresh Meats	New Arrivals	Browse our complete collection of fresh, premium meats	View Collection	/categories/meats	https://images.unsplash.com/photo-1535473895227-bdecb20fb157?w=1200	https://images.unsplash.com/photo-1535473895227-bdecb20fb157?w=800	3	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.805	2026-01-05 04:51:10.805
d77f75c3-dc7f-4a49-8d54-0d764de14510	CAT002	\N	CATEGORY	ACTIVE	Quick & Convenient Meals	Ready to Eat	Discover our range of delicious convenience foods for your busy lifestyle	Explore Convenience Foods	/categories/convenience-food	https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=1200	https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800	4	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.806	2026-01-05 04:51:10.806
78e5527f-795b-4bb1-816b-2d8c5b72b92a	CAT003	\N	CATEGORY	ACTIVE	Fresh Seafood Collection	Premium Quality	Discover our premium selection of fresh seafood	Explore Seafood	/categories/seafood	https://images.unsplash.com/photo-1512909006721-3d6018887383?w=1200	https://images.unsplash.com/photo-1512909006721-3d6018887383?w=800	5	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.807	2026-01-05 04:51:10.807
523418c2-ea5d-4d1f-be0d-958f6ce30e7a	CAT004	\N	CATEGORY	ACTIVE	Fresh From Farm to Table	Farm Fresh	Experience the difference of locally sourced, organic ingredients delivered daily	Learn More	/about/farm-fresh	https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=1200	https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=800	6	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.807	2026-01-05 04:51:10.807
3475a541-fd72-4c21-9a37-7d5c3731021c	CAT002	\N	FOOTER	ACTIVE	Join Our Newsletter	\N	Get exclusive deals and recipes delivered to your inbox	Subscribe	/newsletter/subscribe	https://images.unsplash.com/photo-1505935428862-770b6f24f629?w=1200	https://images.unsplash.com/photo-1505935428862-770b6f24f629?w=800	8	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.808	2026-01-05 04:51:10.808
5f6aaa77-b29c-463f-bc45-44f277cd29e2	CAT003	\N	FOOTER	ACTIVE	Follow Us on Social Media	Connect	Stay updated with our latest products and special offers	Follow	/social	https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=1200	https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800	9	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.809	2026-01-05 04:51:10.809
29e0ef0f-1ba5-4375-8528-86e71013f4e0	CAT004	\N	FOOTER	ACTIVE	Customer Support	24/7	We are here to help you with any questions or concerns	Contact Us	/support	https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1200	https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800	10	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.81	2026-01-05 04:51:10.81
458ba7e3-a29c-4242-bb88-3c6c7ea3308f	CAT002	\N	CONTENT_HERO	ACTIVE	Valentine's Day Special	Coming Soon	Celebrate with our artisan bakery collection	Notify Me	/products/371b2256-4bad-4918-97da-4dea1d19cdaf	https://images.unsplash.com/photo-1509440159596-0249088772ff?w=1200	https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800	11	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.811	2026-01-05 04:51:10.811
ae37ff71-1415-405b-9ba2-3a2f325dddfc	CAT003	\N	SPECIAL_PRICE	ACTIVE	This Week's Special Offer	30% OFF	Wild Caught Salmon - Limited Time Only!	Get Discount	/products/b6128efe-1083-4b91-ac93-e15e357728b2	https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=1200	https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=800	12	2025-01-01 00:00:00	2025-12-31 00:00:00	2026-01-05 04:51:10.814	2026-01-05 04:51:10.814
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (id, cart_id, product_id, quantity, sale_price, created_at, updated_at) FROM stdin;
e40881f9-5e14-4cd1-96df-a00f0493db58	89a8617b-72d7-4d11-af30-22244602b342	52f1a6dc-7962-4b9d-89dc-7045b047279f	2	105000	2026-01-05 07:33:43.023	2026-01-05 07:33:52.711
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carts (id, user_id, status, total_amount, checked_out_at, created_at, updated_at) FROM stdin;
89a8617b-72d7-4d11-af30-22244602b342	user000	ACTIVE	210000	\N	2026-01-05 06:47:52.98	2026-01-05 07:33:52.72
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (product_category_number, name, description, created_at, updated_at) FROM stdin;
CAT001	LIVESTOCK	Livestock products - Fresh premium meats and livestock products	2026-01-05 04:51:10.766	2026-01-05 04:51:10.766
CAT002	CONVENIENCE_FOOD	Convenience food - Quick and ready-to-eat meals for busy lifestyles	2026-01-05 04:51:10.767	2026-01-05 04:51:10.767
CAT003	FISHERIES	Fisheries - Fresh seafood and premium fish products	2026-01-05 04:51:10.768	2026-01-05 04:51:10.768
CAT004	SIDE_DISH	Side dish - Premium oils, condiments, and side dish ingredients	2026-01-05 04:51:10.768	2026-01-05 04:51:10.768
\.


--
-- Data for Name: coupon_histories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupon_histories (id, coupon_id, user_id, order_id, status, issued_at, used_at, expired_at, cancelled_at, discount_applied_amount, purchase_amount_at_use, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupons (id, name, code, type, discount_rate, discount_amount, min_purchase_amount, max_discount_amount, image_url, start_date, end_date, is_active, is_auto_issue, auto_issue_day_of_month, created_at, updated_at, target_grades) FROM stdin;
1ba65719-8a29-4273-b585-ac8f14707e81	VIP Welcome Coupon	VIP-WELCOME-2025	PERCENT	20	\N	100000	50000	\N	2025-01-01 00:00:00	2025-12-31 00:00:00	t	t	2025-01-01 00:00:00	2026-01-05 04:51:10.798	2026-01-05 04:51:10.798	{VIP}
ff02fa7a-32e2-47a3-a87b-98d73abb38ac	VVIP Exclusive Discount	VVIP-EXCLUSIVE-2025	AMOUNT	\N	100000	500000	\N	\N	2025-01-01 00:00:00	2025-12-31 00:00:00	t	t	2025-01-01 00:00:00	2026-01-05 04:51:10.799	2026-01-05 04:51:10.799	{VVIP}
390f97bf-ee70-45b0-80cb-8ccceb2e3763	Premium Member Monthly Bonus	PREMIUM-MONTHLY-2025	PERCENT	15	\N	200000	30000	\N	2025-01-01 00:00:00	2025-12-31 00:00:00	t	t	2025-01-15 00:00:00	2026-01-05 04:51:10.8	2026-01-05 04:51:10.8	{VIP,VVIP}
5f07f58f-8209-424f-be3e-3e5d44c8043d	New Year Special	NEWYEAR-2025	AMOUNT	\N	50000	300000	\N	\N	2025-01-01 00:00:00	2025-01-31 00:00:00	t	f	2025-01-01 00:00:00	2026-01-05 04:51:10.801	2026-01-05 04:51:10.801	{GOLD,SILVER}
\.


--
-- Data for Name: memberships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.memberships (id, name, description, min_price, created_at, updated_at) FROM stdin;
89bcb9a1-42aa-4b38-b7fa-1d5625bc3085	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	1000000	2026-01-05 04:51:09.543	2026-01-05 04:51:09.543
963dd085-a12a-4465-97b9-bc385985b2b3	VIP	Very Important Person - Premium membership with special privileges	500000	2026-01-05 04:51:09.555	2026-01-05 04:51:09.555
d4f9221a-6af8-47f3-b16d-7898e22de868	GOLD	Gold membership - Enhanced benefits and rewards	300000	2026-01-05 04:51:09.557	2026-01-05 04:51:09.557
25a5d28f-abea-45b1-b3eb-78919c4e2074	SILVER	Silver membership - Standard benefits package	150000	2026-01-05 04:51:09.559	2026-01-05 04:51:09.559
861c3c96-0010-4733-add8-d7fc43883eb6	GENERAL	General membership - Entry level membership for users with less than 150000	0	2026-01-05 04:51:09.56	2026-01-05 04:51:09.56
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, order_number, item_wise_order_number, total_order_amount, total_payment_amount, product_id, product_name, product_name_with_options, quantity, recipient, recipient_address_full, recipient_postal_code, recipient_mobile_phone, recipient_phone_number, delivery_message, sale_price, payment_type, payment_method, order_date, orderer_name, orderer_mobile_phone, orderer_id, desired_delivery_date, membership_level_at_order_time, created_at, updated_at, situation, courier_company, invoice_number) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, user_id, amount, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.points (id, date, user_id, membership_level, content, order_number, points_type, available_points_increase, available_points_deduction, available_points_balance, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_discounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_discounts (id, status, product_id, discount_rate, discount_start_date, discount_end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_inquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_inquiries (id, product_id, author_id, created_at, updated_at, content, title) FROM stdin;
\.


--
-- Data for Name: product_inquiry_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_inquiry_answers (id, inquiry_id, answer, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_reviews (id, product_id, author_id, review, rating, created_at, updated_at, image_url) FROM stdin;
5424be10-3f41-499e-9e20-80986f6dafea	52f1a6dc-7962-4b9d-89dc-7045b047279f	user000	no comment	2	2026-01-05 08:04:51.566	2026-01-05 08:04:51.566	https://liflow-s3-bucket.s3.ap-northeast-2.amazonaws.com/product-reviews/user000/png/1767600289907.png
\.


--
-- Data for Name: product_special_offers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_special_offers (id, status, product_id, discount_amount, special_price_applied, start_date, end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, product_code, own_product_code, display_status, sale_status, product_category_number, product_category_new_product_area, product_category_recommended_product_area, product_name, english_product_name, product_name_for_management, supplier_product_name, model_name, product_summary_description, product_brief_description, search_keyword_setting, tax_classification, consumer_price, supply_price, product_price, sale_price, use_sale_price_alternative_text, sale_price_alternative_text, order_quantity_limit_criteria, min_order_quantity, max_order_quantity, reward_points, reward_points_classification, common_event_info, adult_verification, option_usage, item_composition_method, option_display_method, option_set_name, option_input, option_style, button_image_setting, color_setting, required_or_not, out_of_stock_display_text, additional_input_option, additional_input_option_name, additional_input_option_required_or_not, input_character_count, image_registration_detail, image_registration_list, image_registration_small_list, image_registration_thumbnail, manufacturer, supplier, brand, trend, own_classification_code, manufacturing_date, release_date, validity_period_usage, validity_period, origin, product_volume, volume_weight, product_payment_guide, product_delivery_guide, exchange_return_guide, service_inquiry_guide, delivery_info, delivery_method, domestic_overseas_delivery, delivery_area, delivery_fee_prepayment_setting, delivery_period, delivery_fee_classification, delivery_fee_input, product_classification_customs, product_material, english_product_material_customs, fabric_customs, seo_search_engine_exposure_setting, seo_title, seo_author, seo_description, seo_keywords, seo_product_image_alt_text, individual_payment_method_setting, product_delivery_type_code, store_pickup_setting, product_total_weight, hs_code, additional_item_01_today_departure_delivery_usage, additional_item_02_today_departure_delivery_time, additional_item_03_storage_method, additional_item_04_origin, additional_item_05_event, additional_item_06_parcel_delivery, created_at, updated_at, cta_button_url) FROM stdin;
db7b5939-54e9-4520-a8e5-c2fd78c67bd4	PROD001	OWN001	ACTIVE	AVAILABLE	CAT001	\N	\N	Premium Organic Olive Oil	Premium Organic Olive Oil	\N	\N	\N	\N	\N	\N	TAXABLE	35000	25000	30000	28000	\N	\N	\N	1	100	280	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Organic Foods Co.	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	PARCEL	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-05 04:51:10.77	2026-01-05 04:51:10.77	\N
371b2256-4bad-4918-97da-4dea1d19cdaf	PROD002	OWN002	ACTIVE	AVAILABLE	CAT002	\N	\N	Artisan Whole Grain Bread	Artisan Whole Grain Bread	\N	\N	\N	\N	\N	\N	TAXABLE	8000	5000	7000	6500	\N	\N	\N	1	50	65	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Artisan Bakery	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	\N	PARCEL	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-05 04:51:10.773	2026-01-05 04:51:10.773	\N
b6128efe-1083-4b91-ac93-e15e357728b2	PROD003	OWN003	ACTIVE	AVAILABLE	CAT003	\N	\N	Wild Caught Salmon Fillet	Wild Caught Salmon Fillet	\N	\N	\N	\N	\N	\N	TAXABLE	45000	35000	42000	40000	\N	\N	\N	1	20	400	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Ocean Fresh Co.	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	COLD_CHAIN	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-05 04:51:10.774	2026-01-05 04:51:10.774	\N
52f1a6dc-7962-4b9d-89dc-7045b047279f	PROD004	OWN004	ACTIVE	AVAILABLE	CAT003	\N	\N	Premium Wagyu Beef Set	Premium Wagyu Beef Set	\N	\N	\N	\N	\N	\N	TAXABLE	120000	90000	110000	105000	\N	\N	\N	1	10	1050	PERCENTAGE	\N	NO	YES	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Premium Meats Ltd.	\N	\N	\N	\N	\N	\N	\N	\N	4	\N	\N	\N	\N	\N	\N	\N	COLD_CHAIN	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-05 04:51:10.776	2026-01-05 04:51:10.776	\N
3aad91da-f5a1-438d-ba71-b885ab845fec	PROD005	OWN005	ACTIVE	AVAILABLE	CAT004	\N	\N	Organic Vegetable Box (Large)	Organic Vegetable Box (Large)	\N	\N	\N	\N	\N	\N	TAXABLE	55000	40000	50000	48000	\N	\N	\N	1	30	480	PERCENTAGE	\N	NO	NO	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Farm Fresh Organics	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	COLD_CHAIN	DOMESTIC	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-05 04:51:10.778	2026-01-05 04:51:10.778	\N
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recipes (id, title, "authorId", "authorName", date_of_writing, views, status, thumbnail_url, content, ingredients, created_at, updated_at, is_active, category) FROM stdin;
aff97a97-644f-429b-a862-d6c20b1e1812	Classic Korean Kimchi Fried Rice	user020	USER9	2025-11-09 01:26:43.407	266	active	https://example.com/thumbnails/recipe-1.jpg	A delicious and easy kimchi fried rice recipe with bacon and vegetables.	{Rice,Kimchi,Bacon,"Green onion","Sesame oil","Soy sauce",Egg}	2026-01-05 04:51:10.779	2026-01-05 04:51:10.779	t	RECIPE
ac07ce29-330d-4293-a846-47f1adcf3bab	Homemade Italian Pasta Carbonara	user020	USER9	2025-06-16 08:46:14.822	4190	active	https://example.com/thumbnails/recipe-2.jpg	Authentic Italian carbonara with eggs, pecorino cheese, and guanciale.	{Spaghetti,Eggs,"Pecorino cheese",Guanciale,"Black pepper"}	2026-01-05 04:51:10.785	2026-01-05 04:51:10.785	t	RECIPE
6bdc2210-1573-4741-948e-e0480f743b92	Healthy Buddha Bowl	user020	USER9	2025-11-20 23:49:55.013	190	active	https://example.com/thumbnails/recipe-3.jpg	A nutritious bowl packed with quinoa, roasted vegetables, and tahini dressing.	{Quinoa,"Sweet potato",Chickpeas,Kale,Avocado,Tahini,Lemon}	2026-01-05 04:51:10.787	2026-01-05 04:51:10.787	t	RECIPE
e281e48c-bfa9-40cb-95c8-99bd67a8780c	Spicy Thai Green Curry	user015	USER4	2025-11-19 14:32:47.744	3693	active	https://example.com/thumbnails/recipe-4.jpg	Aromatic Thai green curry with chicken and vegetables in coconut milk.	{Chicken,"Green curry paste","Coconut milk","Thai basil","Bamboo shoots","Fish sauce"}	2026-01-05 04:51:10.79	2026-01-05 04:51:10.79	t	RECIPE
a9abed8f-3257-49b4-933f-947d177a70ae	Japanese Ramen Bowl	user019	USER8	2025-05-28 01:43:56.588	1773	active	https://example.com/thumbnails/recipe-5.jpg	Rich and flavorful ramen with pork belly, soft-boiled egg, and noodles.	{"Ramen noodles","Pork belly",Egg,"Green onion",Nori,"Miso paste","Chicken broth"}	2026-01-05 04:51:10.791	2026-01-05 04:51:10.791	t	RECIPE
e54b1f00-1091-4e82-b02b-8267787b83b2	Mediterranean Grilled Chicken	user017	USER6	2025-01-06 13:17:20.375	2306	active	https://example.com/thumbnails/recipe-6.jpg	Grilled chicken marinated in herbs and lemon, served with Greek salad.	{"Chicken breast","Olive oil",Lemon,Oregano,Garlic,Tomatoes,Cucumber,"Feta cheese"}	2026-01-05 04:51:10.793	2026-01-05 04:51:10.793	t	RECIPE
ab9b447f-de1a-40c5-8d77-8bbba78f112c	Vegan Lentil Soup	user015	USER4	2025-02-22 18:49:33.989	2173	active	https://example.com/thumbnails/recipe-7.jpg	Hearty and nutritious lentil soup with vegetables and aromatic spices.	{"Red lentils",Carrots,Celery,Onion,Garlic,Cumin,"Vegetable broth"}	2026-01-05 04:51:10.794	2026-01-05 04:51:10.794	t	DAILY_LIFE
894069f9-8d92-4e1e-b6ed-cf7640e962e5	Classic French Croissant	user021	USER10	2025-12-01 11:29:42.535	2507	active	https://example.com/thumbnails/recipe-8.jpg	Buttery, flaky croissants made from scratch with laminated dough.	{Flour,Butter,Milk,Sugar,Salt,Yeast}	2026-01-05 04:51:10.795	2026-01-05 04:51:10.795	t	REVIEWS
\.


--
-- Data for Name: refresh_token_used; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_token_used (id, "refreshToken", "sessionId") FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, "createdAt", "updatedAt") FROM stdin;
2133cccf-f8a6-4bdb-81d2-e9862cc99ca5	ADMIN	Administrator with full system access	2026-01-05 04:51:09.532	2026-01-05 04:51:09.532
cf5167ff-adbe-41d9-86bc-0388fdcd824c	GENERAL_MANAGER	General Manager (총괄 담당자) - oversees all operations	2026-01-05 04:51:09.537	2026-01-05 04:51:09.537
2e478d03-e4c5-4f22-85b2-fe3cbf5724e7	MANAGER	Manager (담당자) - manages specific areas	2026-01-05 04:51:09.538	2026-01-05 04:51:09.538
687e3928-907a-40b7-ab7e-4e985a37b6af	MD	MD - specialized management role	2026-01-05 04:51:09.539	2026-01-05 04:51:09.539
13aa2545-ddb4-4c05-871d-312b589cd5af	CS_MANAGER	CS Manager (CS 담당자) - customer service management	2026-01-05 04:51:09.54	2026-01-05 04:51:09.54
38dbd03f-ee89-4731-85db-839a119202fa	USER	Basic user role	2026-01-05 04:51:09.541	2026-01-05 04:51:09.541
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, "userId", "refreshToken", ip, "expiredAt") FROM stdin;
be5667ec-a50a-4b8d-a74e-6387cef48cf7	user000	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyMDAwIiwiaWQiOiJ1c2VyMDAwIiwidG9rZW5UeXBlIjoiUkVGUkVTSF9UT0tFTiIsInVzZXJuYW1lIjoiYWRtaW4xQGV4YW1wbGUuY29tIiwiZW1haWwiOiJhZG1pbjFAZXhhbXBsZS5jb20iLCJyb2xlcyI6WyJBRE1JTiJdLCJpYXQiOjE3Njc1OTU1ODQsImV4cCI6MTc2ODIwMDM4NH0.U32TurBpZwr9f4SWNm36xz5i6jqJjeRfT5pI_diXJ0o	\N	2026-01-12 06:46:24
\.


--
-- Data for Name: user_memberships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_memberships (id, "userId", "membershipId", membership_name, membership_description, status, start_date, end_date, created_at, updated_at, updated_by_admin) FROM stdin;
cad4c901-c22c-4428-8add-18d354a02bfc	user000	861c3c96-0010-4733-add8-d7fc43883eb6	GENERAL	General membership - Entry level membership for users with less than 150000	normal	2024-01-26 22:58:49.942	2025-01-25 22:58:49.942	2026-01-05 04:51:10.742	2026-01-05 04:51:10.742	f
00346a69-5eef-4a92-80e9-b31d574ebab0	user001	d4f9221a-6af8-47f3-b16d-7898e22de868	GOLD	Gold membership - Enhanced benefits and rewards	normal	2025-05-24 19:48:12.931	2026-05-24 19:48:12.931	2026-01-05 04:51:10.744	2026-01-05 04:51:10.744	f
e88e51ee-d8bc-4b81-acb4-20ef3dbd9642	user002	25a5d28f-abea-45b1-b3eb-78919c4e2074	SILVER	Silver membership - Standard benefits package	normal	2024-12-29 09:17:42.48	2025-12-29 09:17:42.48	2026-01-05 04:51:10.745	2026-01-05 04:51:10.745	f
60a5543a-35d2-4377-a980-5f0647ecb0ce	user003	d4f9221a-6af8-47f3-b16d-7898e22de868	GOLD	Gold membership - Enhanced benefits and rewards	normal	2024-04-17 16:29:45.432	2025-04-17 16:29:45.432	2026-01-05 04:51:10.747	2026-01-05 04:51:10.747	f
9e0b3a7b-b464-46ee-ad40-82f39cb5083e	user004	25a5d28f-abea-45b1-b3eb-78919c4e2074	SILVER	Silver membership - Standard benefits package	normal	2025-08-20 05:53:37.855	2026-08-20 05:53:37.855	2026-01-05 04:51:10.748	2026-01-05 04:51:10.748	f
ba52128e-4f86-4f74-b8af-91e5fe15b1b6	user005	861c3c96-0010-4733-add8-d7fc43883eb6	GENERAL	General membership - Entry level membership for users with less than 150000	expired	2025-09-26 03:28:58.016	2026-09-26 03:28:58.016	2026-01-05 04:51:10.749	2026-01-05 04:51:10.749	f
ca7ebcd9-f718-4d0c-a3a2-73946f788629	user006	861c3c96-0010-4733-add8-d7fc43883eb6	GENERAL	General membership - Entry level membership for users with less than 150000	normal	2024-02-06 06:45:08.556	2025-02-05 06:45:08.556	2026-01-05 04:51:10.75	2026-01-05 04:51:10.75	f
90532c35-7da1-4e2e-bc24-48d15b28734e	user007	d4f9221a-6af8-47f3-b16d-7898e22de868	GOLD	Gold membership - Enhanced benefits and rewards	normal	2024-12-10 08:23:59.708	2025-12-10 08:23:59.708	2026-01-05 04:51:10.752	2026-01-05 04:51:10.752	f
a2bf56af-b6f9-4e14-aada-ade251f8451a	user008	25a5d28f-abea-45b1-b3eb-78919c4e2074	SILVER	Silver membership - Standard benefits package	normal	2024-11-14 00:41:07.559	2025-11-14 00:41:07.559	2026-01-05 04:51:10.753	2026-01-05 04:51:10.753	f
c5543e72-b27e-49e3-b883-3dce8e2e7c47	user009	861c3c96-0010-4733-add8-d7fc43883eb6	GENERAL	General membership - Entry level membership for users with less than 150000	normal	2025-09-21 11:14:59.574	2026-09-21 11:14:59.574	2026-01-05 04:51:10.754	2026-01-05 04:51:10.754	f
f4afbd1f-5fc6-4c9b-8d9c-fe491ad08359	user010	25a5d28f-abea-45b1-b3eb-78919c4e2074	SILVER	Silver membership - Standard benefits package	normal	2025-06-23 09:15:07.909	2026-06-23 09:15:07.909	2026-01-05 04:51:10.754	2026-01-05 04:51:10.754	f
2e62f207-6c0d-4913-8a9a-bb8cd78eb186	user011	d4f9221a-6af8-47f3-b16d-7898e22de868	GOLD	Gold membership - Enhanced benefits and rewards	normal	2024-10-31 18:16:13.277	2025-10-31 18:16:13.277	2026-01-05 04:51:10.755	2026-01-05 04:51:10.755	f
d75f1cbe-8521-468c-b4fe-a9d68f766cfd	user012	25a5d28f-abea-45b1-b3eb-78919c4e2074	SILVER	Silver membership - Standard benefits package	normal	2024-11-09 10:40:42.685	2025-11-09 10:40:42.685	2026-01-05 04:51:10.756	2026-01-05 04:51:10.756	f
e98ba06a-c506-431a-b87f-36091e1ad776	user013	963dd085-a12a-4465-97b9-bc385985b2b3	VIP	Very Important Person - Premium membership with special privileges	expired	2024-04-01 11:44:05.825	2025-04-01 11:44:05.825	2026-01-05 04:51:10.757	2026-01-05 04:51:10.757	f
83cc998c-4029-4c38-96f1-be3d57068318	user014	89bcb9a1-42aa-4b38-b7fa-1d5625bc3085	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	suspended	2025-12-18 19:28:02.359	2026-12-18 19:28:02.359	2026-01-05 04:51:10.758	2026-01-05 04:51:10.758	f
bfd5c53f-5814-4d54-b81d-83d1bbed9c46	user015	d4f9221a-6af8-47f3-b16d-7898e22de868	GOLD	Gold membership - Enhanced benefits and rewards	normal	2024-07-15 22:53:46.69	2025-07-15 22:53:46.69	2026-01-05 04:51:10.759	2026-01-05 04:51:10.759	f
a7cfce2e-818c-47c6-91ab-5bdc2cb33a7b	user016	89bcb9a1-42aa-4b38-b7fa-1d5625bc3085	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	normal	2024-09-01 12:06:21.334	2025-09-01 12:06:21.334	2026-01-05 04:51:10.76	2026-01-05 04:51:10.76	f
99674c2a-1546-4194-ba52-9e3d6e0f9d25	user017	963dd085-a12a-4465-97b9-bc385985b2b3	VIP	Very Important Person - Premium membership with special privileges	normal	2025-12-16 21:48:28.942	2026-12-16 21:48:28.942	2026-01-05 04:51:10.761	2026-01-05 04:51:10.761	f
fd85d786-2064-4022-9dad-ca449b52aedf	user018	963dd085-a12a-4465-97b9-bc385985b2b3	VIP	Very Important Person - Premium membership with special privileges	normal	2025-12-05 15:26:30.121	2026-12-05 15:26:30.121	2026-01-05 04:51:10.762	2026-01-05 04:51:10.762	f
db7422e4-f2b0-453a-b0dd-f06ff33e8390	user019	d4f9221a-6af8-47f3-b16d-7898e22de868	GOLD	Gold membership - Enhanced benefits and rewards	normal	2025-02-18 20:58:26.738	2026-02-18 20:58:26.738	2026-01-05 04:51:10.762	2026-01-05 04:51:10.762	f
caf8b971-ee67-4a88-bcc6-ebcff3f274c0	user020	89bcb9a1-42aa-4b38-b7fa-1d5625bc3085	VVIP	Very Very Important Person - Ultimate premium membership with exclusive privileges	normal	2024-03-21 08:31:30.237	2025-03-21 08:31:30.237	2026-01-05 04:51:10.764	2026-01-05 04:51:10.764	f
34585724-374b-482b-b9a8-e12d3a3332fb	user021	963dd085-a12a-4465-97b9-bc385985b2b3	VIP	Very Important Person - Premium membership with special privileges	normal	2024-08-27 22:43:02.191	2025-08-27 22:43:02.191	2026-01-05 04:51:10.765	2026-01-05 04:51:10.765	f
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles ("userId", "roleId", "createdAt") FROM stdin;
user000	2133cccf-f8a6-4bdb-81d2-e9862cc99ca5	2026-01-05 04:51:10.732
user001	2133cccf-f8a6-4bdb-81d2-e9862cc99ca5	2026-01-05 04:51:10.732
user002	cf5167ff-adbe-41d9-86bc-0388fdcd824c	2026-01-05 04:51:10.732
user003	cf5167ff-adbe-41d9-86bc-0388fdcd824c	2026-01-05 04:51:10.732
user004	2e478d03-e4c5-4f22-85b2-fe3cbf5724e7	2026-01-05 04:51:10.732
user005	2e478d03-e4c5-4f22-85b2-fe3cbf5724e7	2026-01-05 04:51:10.732
user006	2e478d03-e4c5-4f22-85b2-fe3cbf5724e7	2026-01-05 04:51:10.732
user007	687e3928-907a-40b7-ab7e-4e985a37b6af	2026-01-05 04:51:10.732
user008	687e3928-907a-40b7-ab7e-4e985a37b6af	2026-01-05 04:51:10.732
user009	13aa2545-ddb4-4c05-871d-312b589cd5af	2026-01-05 04:51:10.732
user010	13aa2545-ddb4-4c05-871d-312b589cd5af	2026-01-05 04:51:10.732
user011	13aa2545-ddb4-4c05-871d-312b589cd5af	2026-01-05 04:51:10.732
user012	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user013	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user014	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user015	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user016	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user017	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user018	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user019	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user020	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
user021	38dbd03f-ee89-4731-85db-839a119202fa	2026-01-05 04:51:10.732
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, password, name, "membershipLevel", age, email, phone_number, total_used_points, available_points, registration_date, dormancy_date, withdrawal_date, withdrawal_type, reason_for_withdrawal, created_at, updated_at, total_purchase_amount, dashboard_access, member_access, product_access, order_access, recipe_access, banner_access) FROM stdin;
user000	$2b$10$nO92xuErqDDEN.FlmSSA/O2nU58Uu3pnFV3hAwCFxVlOCIBi3YtYm	ADMIN1	\N	59	admin1@example.com	010-1000-5000	4678	9922	2025-04-26	\N	\N	\N	\N	2026-01-05 04:51:09.611	2026-01-05 04:51:09.611	78036	t	t	t	t	t	t
user001	$2b$10$dB6KIa8OBmCnl3XZWTTK4uOp9Qe3o8xnpBSRP9JDq1cbs//2hBHnu	ADMIN2	\N	66	admin2@example.com	010-1001-5001	19076	730	2025-10-20	\N	\N	\N	\N	2026-01-05 04:51:09.663	2026-01-05 04:51:09.663	373011	t	t	t	t	t	t
user002	$2b$10$bDqfI9dBU04DZiYvQo7ytOprezrVzeWycQFOFiKjTZHWhb3JaNw4u	GENERAL_MANAGER1	\N	66	general_manager1@example.com	010-1002-5002	15414	16738	2025-12-14	\N	\N	\N	\N	2026-01-05 04:51:09.717	2026-01-05 04:51:09.717	190362	t	t	t	t	t	t
user003	$2b$10$3iH3W6MyCPQFmH9/YjNIwuKLUL5r2716VXIg/uhqtG2Kg17oWjjzC	GENERAL_MANAGER2	\N	58	general_manager2@example.com	010-1003-5003	34119	12055	2025-07-26	\N	\N	\N	\N	2026-01-05 04:51:09.77	2026-01-05 04:51:09.77	352732	t	t	t	t	t	t
user004	$2b$10$GMBDA97xnJrgIVlnvrMxuu0F2dI53wMeYcASIAP2SJBVR93AXOfIy	MANAGER1	\N	34	manager1@example.com	010-1004-5004	34955	6646	2025-05-31	\N	\N	\N	\N	2026-01-05 04:51:09.823	2026-01-05 04:51:09.823	272611	t	t	t	t	t	t
user005	$2b$10$KqrwDmv3gpZIfX2ouj6/Aud5Rc4xkKP88Wf5VpNmjWezUh93cY0tm	MANAGER2	\N	59	manager2@example.com	010-1005-5005	39140	1444	2025-05-07	\N	\N	\N	\N	2026-01-05 04:51:09.876	2026-01-05 04:51:09.876	103512	t	t	f	t	t	f
user006	$2b$10$VUolNesYvOlou9KjE23V4upwCLG33z7lKYSnBkWvjbXx2r241UZB6	MANAGER3	\N	35	manager3@example.com	010-1006-5006	21901	9821	2025-11-04	\N	\N	\N	\N	2026-01-05 04:51:09.929	2026-01-05 04:51:09.929	34772	t	t	f	t	t	f
user007	$2b$10$OHlxWnix0VeHduaDvuNb4./tGOQ35sjLmAbt/nigStXtJdcbl4QIy	MD1	\N	27	md1@example.com	010-1007-5007	14198	9427	2025-03-22	\N	\N	\N	\N	2026-01-05 04:51:09.981	2026-01-05 04:51:09.981	381694	t	t	t	t	t	t
user008	$2b$10$bbX1NjbsRKRqDdVV2t0Tg.wYu2COQk3wzVNFIokXHsqqj9kmi2ohC	MD2	\N	49	md2@example.com	010-1008-5008	44241	4520	2025-12-14	\N	\N	\N	\N	2026-01-05 04:51:10.034	2026-01-05 04:51:10.034	227580	t	t	t	t	t	t
user009	$2b$10$psBZ5I6PZuUN0sq7uKuIf./oyotcWL6nJG/0XuTYEfkEnx9Ct.QfS	CS_MANAGER1	\N	34	cs_manager1@example.com	010-1009-5009	20171	10688	2024-10-14	\N	\N	\N	\N	2026-01-05 04:51:10.093	2026-01-05 04:51:10.093	86157	t	t	t	t	t	f
user010	$2b$10$uc7ggE2d/Xf9FT0XAmvs7O8z/5hh.akMANPTiyFERUn/SM5SQob5e	CS_MANAGER2	\N	67	cs_manager2@example.com	010-1010-5010	15681	12259	2025-03-17	\N	\N	\N	\N	2026-01-05 04:51:10.144	2026-01-05 04:51:10.144	294175	t	t	t	t	t	f
user011	$2b$10$d2KN3evgtQhT5hvbVW.IEuDFuLz8hlYTLm6af.dVi.gVheu6qnHZO	CS_MANAGER3	\N	43	cs_manager3@example.com	010-1011-5011	25051	17475	2025-12-23	\N	\N	\N	\N	2026-01-05 04:51:10.195	2026-01-05 04:51:10.195	424740	t	t	t	t	t	f
user012	$2b$10$me6v3l3uhKXfPsJrSEBxEeYaoO2RlMIRW0aXQZ8fD1WzBcjM0wu9S	USER1	\N	28	user1@example.com	010-1012-5012	7517	6275	2024-08-03	\N	\N	\N	\N	2026-01-05 04:51:10.246	2026-01-05 04:51:10.246	267151	t	f	t	t	t	f
user013	$2b$10$kQ2w6whMns34SapTYeM9AuPT0PdnCHaZmjMTO8WpPulzgd.Puq0Dm	USER2	\N	30	user2@example.com	010-1013-5013	35462	15108	2025-01-08	\N	\N	\N	\N	2026-01-05 04:51:10.299	2026-01-05 04:51:10.299	576544	t	f	t	t	t	f
user014	$2b$10$VsuwVH24Ev57UEcB8ytVN.yBtxuN8VvGIMGcS9QKsABCvaB/IDM0W	USER3	\N	23	user3@example.com	010-1014-5014	28900	2782	2024-11-29	\N	\N	\N	\N	2026-01-05 04:51:10.351	2026-01-05 04:51:10.351	1062948	t	f	t	t	t	f
user015	$2b$10$DI/Cgpz1SlkoRZTRO3VnfO5.V.ncVYCY05ErLz7l8o0Al6zUdY8cC	USER4	\N	24	user4@example.com	010-1015-5015	5085	15371	2025-10-12	\N	\N	\N	\N	2026-01-05 04:51:10.405	2026-01-05 04:51:10.405	467737	t	f	t	t	t	f
user016	$2b$10$/9RmcYu9cz1/0ZK8ujiT5u8ojOycAtx98pa/F6mhm1gX1.K8LSMJe	USER5	\N	28	user5@example.com	010-1016-5016	43709	11963	2024-12-22	\N	\N	\N	\N	2026-01-05 04:51:10.457	2026-01-05 04:51:10.457	1480721	t	f	t	t	t	f
user017	$2b$10$5oRVajjM/OePfVUKjfGgQ.NPC0BMcuIIrc.DhAns25ej/DUJZgS8O	USER6	\N	58	user6@example.com	010-1017-5017	19237	15168	2025-08-10	\N	\N	\N	\N	2026-01-05 04:51:10.511	2026-01-05 04:51:10.511	511552	t	f	t	t	t	f
user018	$2b$10$HLRRQyj17zG0yFhfrWM1UOnkQPdIXBcKig5FK2FM/QqxZ1z9o/wQW	USER7	\N	22	user7@example.com	010-1018-5018	2735	16430	2024-01-21	\N	\N	\N	\N	2026-01-05 04:51:10.565	2026-01-05 04:51:10.565	683677	t	f	t	t	t	f
user019	$2b$10$w44LpN9RFH792d02YPHYA.SHFDAurBjGRpIbn.tG9tKGxRMCrThE.	USER8	\N	28	user8@example.com	010-1019-5019	28195	12844	2024-10-11	\N	\N	\N	\N	2026-01-05 04:51:10.619	2026-01-05 04:51:10.619	308453	t	f	t	t	t	f
user020	$2b$10$k76P3APpx.FSlrwiZAoByevLYPVRxIhddZMoH2V53wz67gU1nXE92	USER9	\N	48	user9@example.com	010-1020-5020	3530	13214	2025-09-18	\N	\N	\N	\N	2026-01-05 04:51:10.673	2026-01-05 04:51:10.673	1604573	t	f	t	t	t	f
user021	$2b$10$ZZejnPLJFLiig45S5.HL2u7.PjKlmFBB09QZG1fo9iV3n59HtlqNm	USER10	\N	31	user10@example.com	010-1021-5021	43537	2930	2025-07-03	\N	\N	\N	\N	2026-01-05 04:51:10.726	2026-01-05 04:51:10.726	878662	t	f	t	t	t	f
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (product_category_number);


--
-- Name: coupon_histories coupon_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: points points_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_pkey PRIMARY KEY (id);


--
-- Name: product_discounts product_discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_discounts
    ADD CONSTRAINT product_discounts_pkey PRIMARY KEY (id);


--
-- Name: product_inquiries product_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_inquiries
    ADD CONSTRAINT product_inquiries_pkey PRIMARY KEY (id);


--
-- Name: product_inquiry_answers product_inquiry_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_inquiry_answers
    ADD CONSTRAINT product_inquiry_answers_pkey PRIMARY KEY (id);


--
-- Name: product_reviews product_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_pkey PRIMARY KEY (id);


--
-- Name: product_special_offers product_special_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_special_offers
    ADD CONSTRAINT product_special_offers_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: refresh_token_used refresh_token_used_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_token_used
    ADD CONSTRAINT refresh_token_used_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: user_memberships user_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT user_memberships_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY ("userId", "roleId");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: banners_display_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_display_order_idx ON public.banners USING btree (display_order);


--
-- Name: banners_start_date_end_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_start_date_end_date_idx ON public.banners USING btree (start_date, end_date);


--
-- Name: banners_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_status_idx ON public.banners USING btree (status);


--
-- Name: banners_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banners_type_idx ON public.banners USING btree (type);


--
-- Name: cart_items_cart_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_items_cart_id_idx ON public.cart_items USING btree (cart_id);


--
-- Name: cart_items_cart_id_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cart_items_cart_id_product_id_key ON public.cart_items USING btree (cart_id, product_id);


--
-- Name: cart_items_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_items_product_id_idx ON public.cart_items USING btree (product_id);


--
-- Name: carts_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX carts_status_idx ON public.carts USING btree (status);


--
-- Name: carts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX carts_user_id_idx ON public.carts USING btree (user_id);


--
-- Name: carts_user_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX carts_user_id_key ON public.carts USING btree (user_id);


--
-- Name: categories_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX categories_name_key ON public.categories USING btree (name);


--
-- Name: categories_product_category_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX categories_product_category_number_key ON public.categories USING btree (product_category_number);


--
-- Name: coupon_histories_coupon_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_coupon_id_idx ON public.coupon_histories USING btree (coupon_id);


--
-- Name: coupon_histories_issued_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_issued_at_idx ON public.coupon_histories USING btree (issued_at);


--
-- Name: coupon_histories_order_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_order_id_idx ON public.coupon_histories USING btree (order_id);


--
-- Name: coupon_histories_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_status_idx ON public.coupon_histories USING btree (status);


--
-- Name: coupon_histories_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupon_histories_user_id_idx ON public.coupon_histories USING btree (user_id);


--
-- Name: coupons_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupons_code_idx ON public.coupons USING btree (code);


--
-- Name: coupons_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX coupons_code_key ON public.coupons USING btree (code);


--
-- Name: coupons_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupons_is_active_idx ON public.coupons USING btree (is_active);


--
-- Name: coupons_start_date_end_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coupons_start_date_end_date_idx ON public.coupons USING btree (start_date, end_date);


--
-- Name: memberships_min_price_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX memberships_min_price_idx ON public.memberships USING btree (min_price);


--
-- Name: memberships_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX memberships_name_idx ON public.memberships USING btree (name);


--
-- Name: memberships_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX memberships_name_key ON public.memberships USING btree (name);


--
-- Name: orders_order_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_order_number_idx ON public.orders USING btree (order_number);


--
-- Name: orders_order_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX orders_order_number_key ON public.orders USING btree (order_number);


--
-- Name: points_order_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX points_order_number_key ON public.points USING btree (order_number);


--
-- Name: points_user_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX points_user_id_key ON public.points USING btree (user_id);


--
-- Name: product_discounts_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_discounts_product_id_key ON public.product_discounts USING btree (product_id);


--
-- Name: product_special_offers_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_special_offers_product_id_key ON public.product_special_offers USING btree (product_id);


--
-- Name: recipes_authorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "recipes_authorId_idx" ON public.recipes USING btree ("authorId");


--
-- Name: recipes_date_of_writing_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recipes_date_of_writing_idx ON public.recipes USING btree (date_of_writing);


--
-- Name: recipes_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recipes_status_idx ON public.recipes USING btree (status);


--
-- Name: refresh_token_used_refreshToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "refresh_token_used_refreshToken_key" ON public.refresh_token_used USING btree ("refreshToken");


--
-- Name: refresh_token_used_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "refresh_token_used_sessionId_idx" ON public.refresh_token_used USING btree ("sessionId");


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: sessions_refreshToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sessions_refreshToken_key" ON public.sessions USING btree ("refreshToken");


--
-- Name: sessions_userId_expiredAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sessions_userId_expiredAt_idx" ON public.sessions USING btree ("userId", "expiredAt");


--
-- Name: user_memberships_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_memberships_id_key ON public.user_memberships USING btree (id);


--
-- Name: user_memberships_membershipId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_memberships_membershipId_idx" ON public.user_memberships USING btree ("membershipId");


--
-- Name: user_memberships_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_memberships_userId_idx" ON public.user_memberships USING btree ("userId");


--
-- Name: user_memberships_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_memberships_userId_key" ON public.user_memberships USING btree ("userId");


--
-- Name: user_memberships_userId_membershipId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_memberships_userId_membershipId_idx" ON public.user_memberships USING btree ("userId", "membershipId");


--
-- Name: user_roles_roleId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_roles_roleId_idx" ON public.user_roles USING btree ("roleId");


--
-- Name: user_roles_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_roles_userId_idx" ON public.user_roles USING btree ("userId");


--
-- Name: users_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_id_key ON public.users USING btree (id);


--
-- Name: banners banners_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_items cart_items_cart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_cart_id_fkey FOREIGN KEY (cart_id) REFERENCES public.carts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_items cart_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: carts carts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coupon_histories coupon_histories_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coupon_histories coupon_histories_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: coupon_histories coupon_histories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_histories
    ADD CONSTRAINT coupon_histories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_orderer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_orderer_id_fkey FOREIGN KEY (orderer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: points points_order_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_order_number_fkey FOREIGN KEY (order_number) REFERENCES public.orders(order_number) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: points points_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_discounts product_discounts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_discounts
    ADD CONSTRAINT product_discounts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_inquiries product_inquiries_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_inquiries
    ADD CONSTRAINT product_inquiries_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_inquiries product_inquiries_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_inquiries
    ADD CONSTRAINT product_inquiries_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_inquiry_answers product_inquiry_answers_inquiry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_inquiry_answers
    ADD CONSTRAINT product_inquiry_answers_inquiry_id_fkey FOREIGN KEY (inquiry_id) REFERENCES public.product_inquiries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_reviews product_reviews_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_reviews product_reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_special_offers product_special_offers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_special_offers
    ADD CONSTRAINT product_special_offers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_product_category_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_category_number_fkey FOREIGN KEY (product_category_number) REFERENCES public.categories(product_category_number) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: recipes recipes_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT "recipes_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: refresh_token_used refresh_token_used_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_token_used
    ADD CONSTRAINT "refresh_token_used_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_memberships user_memberships_membershipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT "user_memberships_membershipId_fkey" FOREIGN KEY ("membershipId") REFERENCES public.memberships(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_memberships user_memberships_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT "user_memberships_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict FoaJ6EfGgApeWueOYygvKmHHpJpOcUcWJAvcZ3VVHyVRa0eqf4c63wqRght4sQk

